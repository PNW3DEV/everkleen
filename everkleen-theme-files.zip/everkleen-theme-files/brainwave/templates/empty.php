<h1><?php _e( 'Sorry there doesn\'t appear to be content here!', 'brainwave' ); ?></h1>
<p><?php _e( 'Try searching for what you\'re looking for:', 'brainwave' ); ?></p>
<?php get_search_form(); ?>
