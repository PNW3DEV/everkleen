<?php
/**
 * Product Loop End
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
?>
<div class="products-loader">
	<div class="preloader loading">
  	<span class="slice"></span>
  	<span class="slice"></span>
  	<span class="slice"></span>
  	<span class="slice"></span>
  	<span class="slice"></span>
  	<span class="slice"></span>
	</div>
</div>

</ul>
