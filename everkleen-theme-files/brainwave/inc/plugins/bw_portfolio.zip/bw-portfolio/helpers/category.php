<?php

/**
 * Blocks Categoryes
 */
class BW_Block_Categories {

	/**
	 * render meta box
	 */
	public static function categoryMetaBox( $post ) {
		global $wpdb;
		$result = $wpdb->get_results( "SELECT id, name FROM " . $wpdb->prefix . "bw_block_categories WHERE block_type = \"" . $post->post_type . "\"" );
		$cat_ids = get_post_meta( $post->ID, 'block_categories', true );

		$add_text = __( 'Add Category', 'brainwave' );
		$remove_text = __( 'Remove Category', 'brainwave' );

		?>
		<div id="brainwave-category" class="category-block">
			<div class="categories-list">
				<ul>
				<?php foreach ( $result as $cat ) : ?>
					<li>
						<label class="selectit">
							<input id="in-popular-category-41" type="checkbox" <?php echo ( strpos( $cat_ids, $cat->id ) !== false ) ? 'checked' : '' ?> value="<?php echo esc_attr( $cat->id ); ?>"><?php echo $cat->name; ?>
						</label>
					</li>
				<?php endforeach; ?>
				</ul>
			</div>

			<div class="wp-hidden-children">
				<h4>
					<a id="block-category-add-toggle" href="#category-add" class="hide-if-no-js">+ <?php echo $add_text ?></a>&nbsp;&nbsp;&nbsp;
					<a id="block-category-remove-toggle" href="#remove-add" class="hide-if-no-js">- <?php echo $remove_text ?></a>
				</h4>

				<p id="category-add" class="category-add wp-hidden-child">
					<input type="text" name="newcategory" id="newcategory" class="form-required form-input-tip" placeholder="<?php _e( 'New Category Name', 'brainwave' ) ?>" aria-required="true">
					<input type="button" class="button catadd" value="Add">
					<input type="hidden" name="block_type" value="<?php echo $post->post_type ?>">
				</p>

				<input type="hidden" class="category-ids" name="block_categories" value="<?php echo esc_attr( $cat_ids ); ?>">

			</div>
		</div>
		<?php
	}

	/**
	 * Get block category
	 */
	public static function getCategory( $ids ) {
		global $wpdb;

		return $wpdb->get_results( "SELECT id, name FROM " . $wpdb->prefix . "bw_block_categories WHERE id IN ({$ids})" );
	}

	public static function getAllCategories( $type ) {
		global $wpdb;

		return $wpdb->get_results( "SELECT id, name, slug FROM {$wpdb->prefix}bw_block_categories WHERE block_type = '{$type}'" );
	}

	/**
	 * Save block category
	 */
	public static function saveCategory() {
		global $wpdb;

		$type = $_POST['options']['type'];
		$name = $_POST['options']['name'];
		$slug = self::slugify( self::bw_ru2Lat( $name ) );

		$result = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM " . $wpdb->prefix . "bw_block_categories WHERE slug = '%s'", $slug ) );

		if ( $result == NULL ) {
			$wpdb->insert(
				$wpdb->prefix . 'bw_block_categories',
				array(
					'block_type' => $type,
					'name' => trim( $name ),
					'slug' => $slug ),
				array( '%s', '%s', '%s' )
			);

			$result = $wpdb->get_row( 'SELECT id, name FROM ' . $wpdb->prefix . 'bw_block_categories ORDER BY id DESC LIMIT 1', ARRAY_A );

			echo json_encode( $result );
		}

		die();
	}

	/**
	 * Save block category
	 */
	public static function removeCategory() {
		global $wpdb;

		$ids_string = implode( ', ', $_POST['options']['ids'] );

		$result = $wpdb->query( $wpdb->prepare( "DELETE FROM " . $wpdb->prefix . "bw_block_categories WHERE id IN (%s)", $ids_string ) );

		die();
	}

	/**
	 * text to slug
	 */
	public static function slugify( $text ) {
		$text = preg_replace('~[^\\pL\d]+~u', '-', $text);
		$text = trim($text, '-');
		$text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
		$text = strtolower($text);
		$text = preg_replace('~[^-\w]+~', '', $text);

		if ( empty( $text ) ) {
			return 'n-a';
		}

		return $text;
	}

	/**
	 * rus to lat
	 */
	public static function bw_ru2Lat($string) {
		$replace = array(
			"'"=>"",
			"`" => "",
			"а" => "a","А" => "a",
			"б" => "b","Б" => "b",
			"в" => "v","В" => "v",
			"г" => "g","Г" => "g",
			"д" => "d","Д" => "d",
			"е" => "e","Е" => "e",
			"ж" => "zh","Ж" => "zh",
			"з" => "z","З" => "z",
			"и" => "i","И" => "i",
			"й" => "y","Й" => "y",
			"к" => "k","К" => "k",
			"л" => "l","Л" => "l",
			"м" => "m","М" => "m",
			"н" => "n","Н" => "n",
			"о" => "o","О" => "o",
			"п" => "p","П" => "p",
			"р" => "r","Р" => "r",
			"с" => "s","С" => "s",
			"т" => "t","Т" => "t",
			"у" => "u","У" => "u",
			"ф" => "f","Ф" => "f",
			"х" => "h","Х" => "h",
			"ц" => "c","Ц" => "c",
			"ч" => "ch","Ч" => "ch",
			"ш" => "sh","Ш" => "sh",
			"щ" => "sch","Щ" => "sch",
			"ъ" => "","Ъ" => "",
			"ы" => "y","Ы" => "y",
			"ь" => "","Ь" => "",
			"э" => "e","Э" => "e",
			"ю" => "yu","Ю" => "yu",
			"я" => "ya","Я" => "ya",
			"і" => "i","І" => "i",
			"ї" => "yi","Ї" => "yi",
			"є"  =>  "e","Є" => "e"
		);
		return $str = iconv( "UTF-8","UTF-8//IGNORE",strtr( $string, $replace ) );
	}
}

add_action('wp_ajax_bw_save_category', array( 'BW_Block_Categories', 'saveCategory' ) );
add_action('wp_ajax_bw_remove_category', array( 'BW_Block_Categories', 'removeCategory' ) );
