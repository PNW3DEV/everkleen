var $ = jQuery;

/* ------------------------------------
 * LOAD START
 -------------------------------------*/
$( window ).load(function() {

  //init
  bw_init();

  // carousel
  carousel();

  // isotope
	isotopeInit();

});
/* ------------------------------------
 * LOAD END
 -------------------------------------*/

 /* ------------------------------------
  * Ready function Start
  -------------------------------------*/
 function bw_init() {

 	if ($.fn.elevateZoom) {
 		var image      = $( '.general-img' ).find( 'img' ),
 			zoomWidth  = 458,
 			zoomHeight = 458,
 			zoomType   = 'window';

 		if ( ( $( 'body' ).width() ) < 992 ) {
 			zoomWidth  = 0;
 			zoomHeight = 0;
 			zoomType   = 'inner';
 		}

 		image.removeData( 'elevateZoom' );
 		$( '.zoomContainer' ).remove();

 		image.elevateZoom({
 			gallery            : 'thumblist',
 			cursor             : 'crosshair',
 			galleryActiveClass : 'active',
 			zoomWindowWidth    : zoomWidth,
 			zoomWindowHeight   : zoomHeight,
 			borderSize         : 0,
 			borderColor        : 'none',
 			lensFadeIn         : true,
 			zoomWindowFadeIn   : true,
 			zoomType		   : zoomType
 		});
 	}

 	// html shop helper
 	// shop();

 	$( '.select-sorting .active' ).click(function() {
 		$( this ).closest( '.select-sorting' ).addClass( 'open' );
 		// return false;
 	});

 	$( '.select-sorting .list li' ).click(function() {
 		$( '.select-sorting .active span' ).text( $( this ).html() );
 		$( '.select-sorting' ).removeClass( 'open' );
 		// return false;
 	});

 	// slider range
 	if ( $('#price-range').length ) {

 		$( "#price-range" ).slider({
 	    range: true,
 	    min: $( '.price_range_amount' ).data( 'min' ),
 	    max: $( '.price_range_amount' ).data( 'max' ),
 	    values: [ $( '.price_range_amount' ).data( 'current-min' ), $( '.price_range_amount' ).data( 'current-max' ) ],
 	    slide: function( event, ui ) {
 	      // $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
 				$( '#price-range > span:nth-child(4)' ).html( '<span>' + ui.values[ 0 ] + '</span>' );
 	    	$( '#price-range > span:nth-child(5)' ).html( '<span>' + ui.values[ 1 ] + '</span>' );
 				$( '#price-range > input[name=curr_min_price]' ).val(ui.values[ 0 ] );
 				$( '#price-range > input[name=curr_max_price]' ).val(ui.values[ 1 ] );
 	    },
 	    create: function( event, ui ) {
 	    	$( '#price-range > span:nth-child(4)' ).html( '<span>' + $( '.price_range_amount' ).data( 'current-min' ) + '</span>' );
 	    	$( '#price-range > span:nth-child(5)' ).html( '<span>' + $( '.price_range_amount' ).data( 'current-max' ) + '</span>' );
 				$( '#price-range > input[name=curr_min_price]' ).val( $( '.price_range_amount' ).data( 'current-min' ) );
 				$( '#price-range > input[name=curr_max_price]' ).val( $( '.price_range_amount' ).data( 'current-max' ) );
 	    }
 	  });

 	  $( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) +
 	    " - $" + $( "#slider-range" ).slider( "values", 1 ) );

 	}

 	// portfolio focus
 	$( '.portfolio-filter button' ).hover(function() {
 		$( '.portfolio-list .portfolio-item:not('+ $( this ).data( 'filter' ) +')' ).addClass( 'opacity' );
 	}, function() {
 		$( '.portfolio-list .portfolio-item:not('+ $( this ).data( 'filter' ) +')' ).removeClass( 'opacity' );
 	});

 	// work tabs
 	$( '.work-process a' ).click(function (e) {
 		e.preventDefault();
 		$(this).tab( 'show' );
 	});

 	// Clients item width
 	$( '.client-item a' ).each(function() {
 		$(this).width($(this).closest('div').width());
 	});

 	// Set height for home section
 	$( '.video-bg, .image-bg, .home-text-rotate' ).css( 'height', $( window ).height() );

 	// Set height and width for paralax portfolio item
 	$( '.info-wrapper' ).css( {'height': $( '.portfolio-item' ).height(), 'width': $( '.portfolio-item' ).width()} );

 	// Set not found page height
 	$( '.not-found' ).css( {'height': $( window ).height(), 'width': $( window ).width()} );

 	// Text rotator
 	$( ".js-rotating" ).each(function() {
 		var $this = $( this );
 		$this.Morphext({
 			animation: $this.data( 'animation' ),
 		    separator: ",",
 		    speed: 3000,
 		});
 	});

 	/* ------------------------------------
 	 * Animation Progress Bars START
 	 -------------------------------------*/
 	$( '[data-progress-animation]' ).each(function() {
 		$(this).one('inview', function(){
 			var $this = $(this);
 			var delay = ( $this.attr( 'data-animation-delay' ) ? $this.attr( 'data-animation-delay' ) : 1);

 			setTimeout( function() {

 				$this.addClass( 'animated' );

 				$( { someValue: 0 } ).animate( { someValue: $this.attr( 'data-progress-animation' ) }, {
 					duration: 1550,
 					step: function() {
 						$this.attr( 'data-progress-text', Math.round( this.someValue ) );
 					}
 				} );
 			}, delay );
 		});
 	});
 	/* ------------------------------------
 	 * Animation Progress Bars END
 	 -------------------------------------*/

 	/* ------------------------------------
 	 * Animation Counter START
 	 -------------------------------------*/
 	$( '[data-counter-animation]' ).each(function() {
 		var $this = $( this ),
 			$counter = $this.find( '.count' );
 		$(this).one('inview', function(){
 			setTimeout( function() {
 				$( { someValue: 0 } ).animate( { someValue: $this.attr( 'data-counter-animation' ) }, {
 					duration: 1000,
 					step: function() {
 						$counter.text( Math.round( this.someValue ) );
 					}
 				} );
 			}, 0 );
 		});
 	});
 	/* ------------------------------------
 	 * Animation Counter END
 	 -------------------------------------*/

 	/* ------------------------------------
 	 * Animation Layers START
 	 -------------------------------------*/
 	var wow = new WOW({
 		boxClass: 'wow',
 		animateClass: 'animated',
 		offset: 90,
 		mobile: false,
 		live: true
     });

     wow.init();
 	/* ------------------------------------
 	 * Animation Layers END
 	 -------------------------------------*/

 	/* ------------------------------------
 	 * Popup gallery START
 	 -------------------------------------*/
 	$('.popup-gallery').magnificPopup({
 		delegate: 'a',
 		type: 'image',
 		showCloseBtn: true,
 		gallery: {
 			enabled: true,
 			navigateByImgClick: true,
 			preload: [0,1]
 		}
 	});
 	/* ------------------------------------
 	 * Popup gallery END
 	 -------------------------------------*/

 	/* ------------------------------------
 	 * Video popup START
 	 -------------------------------------*/
 	$('.popup-youtube, .popup-vimeo').magnificPopup({
 		disableOn: 700,
 		type: 'iframe',
 		mainClass: 'mfp-fade',
 		removalDelay: 160,
 		preloader: false,
 		fixedContentPos: false,
 	});
 	/* ------------------------------------
 	 * Video popup END
 	 -------------------------------------*/

 }

 /* ------------------------------------
  * READY BEGIN
  -------------------------------------*/
 $( document ).ready(function(){
 	'use strict';

  /* ------------------------------------
   * Subscribe START
   -------------------------------------*/
  $(document).on('submit', 'form#subscribe', function ( e ) {
    e.preventDefault();
    var subscriber = $( '.subscriber', this ).val();
    var $this = $(this);

    $( '.subscriber', $this ).css({
      "border-color": "#e9e9e9",
    });

    if ( $this.hasClass( 'send' ) ) {
      return false;
    }

    $this.addClass( 'send' );
    if ( subscriber === '' ) {
      $( '.subscriber', $this ).css({
        "border-color": "rgba(255, 159, 136, 1)",
      });
      $( '.msg', $this ).html( 'Email field is empty' );
      $( '.msg', $this ).addClass( 'show' );
      $this.removeClass( 'send' );
      return false;
    } else {
        $.post( helpers.ajaxurl, {
          action: 'bw_subscribe',
          subscriber: subscriber,
        },
        function( msg ) {
        $( '.msg', $this ).html( msg );
        $( '.msg', $this ).addClass( 'show' );
        $( 'input[name="email"]', $this ).val( '' );
        $this.removeClass( 'send' );
        });
    }

  } );
  /* ------------------------------------
   * Subscribe END
   -------------------------------------*/
   /* ------------------------------------
 	 * Mailchimp Subscribe START
 	 -------------------------------------*/
 	$(document).on('submit', 'form#chimp', function ( e ) {
 		e.preventDefault();
   	var subscriber = $('.subscriber', this).val();
   	var mcapi = $('#mcapi', this).val();
   	var mclistid = $('#mclistid', this).val();
 		var $this = $( this );
 		$( '.subscriber', $this ).css({
 			"border-color": "#e9e9e9",
 		});

 		if ( $this.hasClass( 'send' ) ) {
 			return false;
 		}

 		$this.addClass( 'send' );
 		if ( subscriber === '' ) {
 			$( '.subscriber', $this ).css({
 				"border-color": "rgba(255, 159, 136, 1)",
 			});
 			$( '.msg', $this ).html( 'Email field is empty' );
 			$( '.msg', $this ).addClass( 'show' );
 			$this.removeClass( 'send' );
 			return false;
 		} else {
     		$.post( helpers.ajaxurl, {
     			action: 'bw_subscribe_mailchimp',
     			mcapi: mcapi,
     			mclistid: mclistid,
 					subscriber: subscriber,
     		},
     		function( msg ) {
					$( '.msg', $this ).text( msg );
 					$( '.msg', $this ).addClass( 'show' );
 					$( 'input[name="email"]', $this ).val( '' );
 					$this.removeClass( 'send' );
     		});
     	}
 	} );
 	/* ------------------------------------
 	 * Mailchimp Subscribe END
 	 -------------------------------------*/


 	// mop init
 	mapInit();

 	/* ------------------------------------
 	 * Map animation START
 	 -------------------------------------*/
 	$( 'body' ).on( 'click', '.map-block a', function() {
 		if ( ! $(this).closest('.page-section').hasClass('open') ) {
 			$(this).closest('.page-section').addClass('open');
 			$(this).closest('.page-section').find('.container').css('top', $('.map-content').height());
 		} else {
 			$(this).closest('.page-section').removeClass('open');
 			$(this).closest('.page-section').find('.container').css('top', '0px');
 		}
 		return false;
 	} );
 	/* ------------------------------------
 	 * Map animation END
 	 -------------------------------------*/
});

 /* ------------------------------------
  * Ready function END
  -------------------------------------*/

 /* ------------------------------------
  * Isotope START
  -------------------------------------*/
 function isotopeInit() {
 	// init Isotope
 	var $isotopeContainer = $( '.portfolio-list:not(.paralax)' ).isotope({
 		percentPosition: true,
 		masonry: {
 			columnWidth: '.grid-sizer'
 		}
 	});

 	// filter items on button click
 	$( '.portfolio-filter' ).on( 'click', 'button', function() {
 		$( '.portfolio-filter button' ).removeClass( 'active' );
 		$( this ).addClass( 'active' );
 		var filterValue = $( this ).attr( 'data-filter' );
 		$isotopeContainer.isotope({ filter: filterValue });
 	});
 }
 /* ------------------------------------
  * Isotope END
  -------------------------------------*/

  /* ------------------------------------
   * Map START
   -------------------------------------*/

  function mapInit() {
  	if ( $( "#map-canvas" ).length > 0 ) {

  		mapInitialize();

  		$(window).resize( mapInitialize );
  	}
  }

  function mapInitialize() {

  	var mapLon = $( "#map-canvas" ).data( "map-lon" );  // Longitude
  	var mapLat = $( "#map-canvas" ).data( "map-lat" );  // Latitude

  	// Marker
  	var mapMarkerLon = $( "#map-canvas" ).data( "map-marker-lon" );  // Longitude
  	var mapMarkerLat = $( "#map-canvas" ).data( "map-marker-lat" );  // Latitude
  	var mapMarkerTitle = $( "#map-canvas" ).data( "map-marker-title" );  // Latitude

  	//Default
  	if ( mapLon === undefined ) { mapLon = -34.697; }
  	if ( mapLat === undefined ) { mapLat = 151.22; }

  	if ( mapMarkerLon === undefined ) { mapMarkerLon = ""; }
  	if ( mapMarkerLat === undefined ) { mapMarkerLat = ""; }
  	if ( mapMarkerTitle === undefined ) { mapMarkerTitle = ""; }

  	if ( $( "#map-canvas" ).length > 0 ) {
  		var center = new google.maps.LatLng( mapLon, mapLat );
  	}

  	var roadAtlasStyles = [{"featureType":"administrative","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"visibility":"simplified"},{"color":"#fcfcfc"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"visibility":"simplified"},{"color":"#fcfcfc"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"visibility":"simplified"},{"color":"#dddddd"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"visibility":"simplified"},{"color":"#dddddd"}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"visibility":"simplified"},{"color":"#eeeeee"}]},{"featureType":"water","elementType":"geometry","stylers":[{"visibility":"simplified"},{"color":"#dddddd"}]}];

  	var mapOptions = {
  		zoom: 12,
  		center: center,
  		draggable: true,
  		disableDefaultUI: true,
  		disableDoubleClickZoom: true,
  		scrollwheel: false,
  		mapTypeControlOptions: {
  			mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'usroadatlas']
  		}
  	};

  	var map = new google.maps.Map(document.getElementById( 'map-canvas' ), mapOptions);

  	var marker = new google.maps.Marker({
  		position: new google.maps.LatLng( mapMarkerLon, mapMarkerLat ),
  		map: map,
  		title: mapMarkerTitle
  	});

  	var styledMapOptions = {
  		name: 'US Road Atlas'
  	};

  	var usRoadMapType = new google.maps.StyledMapType( roadAtlasStyles, styledMapOptions );

  	map.mapTypes.set( 'usroadatlas', usRoadMapType );
  	map.setMapTypeId( 'usroadatlas' );
  }

  /* ------------------------------------
   * Map END
   -------------------------------------*/


/* ------------------------------------
 * Post carousel START
 -------------------------------------*/
function carousel() {
	setTimeout(function() {
		if ( $( '.default-carousel' ).length > 0 ) {
			$( '.default-carousel' ).each( function() {

				var responsive = false,
            nav = false,
            dots = false,
						margin = 0;

				if ( $( this ).hasClass( 'no-arrow' ) ) {
					nav = false;
				} else {
					nav = true;
				}

				if ( $( this ).hasClass( 'no-dots' ) ) {
					dots = false;
				} else {
					dots = true;
				}

				if ( $( this ).hasClass( 'team-carousel' ) ) {
					responsive = {
						0: {
							items: 2,
						},
						480: {
							items: 3,
						},
						768: {
							items: 4,
						}
					};
				}

				if ( $( this ).hasClass( 'recent-works' ) ) {
					responsive = {
						0: {
							items: 2,
						},
						480: {
							items: 3,
						},
						768: {
							items: 4,
						}
					};
				}

				if ( $( this ).hasClass( 'client-carousel' ) ) {
					responsive = {
						0: {
							items: 2,
						},
						480: {
							items: 3,
						},
						768: {
							items: 6,
						}
					};

					margin = 30;
				}

				if ( $( this ).hasClass( '4-items' ) ) {
					responsive = {
						0: {
							items: 2,
						},
						480: {
							items: 3,
						},
						768: {
							items: 4,
						}
					};

					margin = 30;
				}

				if ( ! $( this ).hasClass( 'animation-fade' ) ) {
					$( this ).owlCarousel({
						themeClass: 'brainwave',
						navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
						lazyLoad: true,
						mouseDrag: false,
						nav: nav,
						dots: dots,
						loop: true,
						items: 1,
						autoHeight: true,
						responsive: responsive,
						margin: margin
					});
				} else {
					$( this ).owlCarousel({
						themeClass: 'brainwave',
						navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
						lazyLoad: true,
						mouseDrag: false,
						nav: nav,
						dots: dots,
						loop: true,
						items: 1,
						autoHeight: true,
						animateIn: 'fadeIn',
						animateOut: 'fadeOut',
						responsive: responsive
					});
				}

			} );
		}
	}, 200);
}
/* ------------------------------------
 * Post carousel END
 -------------------------------------*/
