var $ = jQuery;

$(document).ready(function($){

  /**
   * Add block category
   */
  $('#block-category-add-toggle').click(function() {
      $('#category-add').show();
      return false;
  });

  $('#brainwave-category .catadd').click(function() {
      $.ajax({
          type: "POST",
          url : ajaxurl,
          data: {
              action : 'bw_save_category',
              options: {
                  'type': $('input[name="block_type"]').val(),
                  'name': $('input[name="newcategory"]').val()
              }
          },
          success: function(data) {
              if (data) {
                  data = JSON.parse(data);
                  $('.categories-list ul').prepend('<li><label class="selectit"><input id="in-popular-category-41" type="checkbox" value="' + data.id + '">' + data.name + '</label></li>');
                  $('input[name="newcategory"]').val('');
              }
          }
      });

      return false;
  });

  /**
   * Remove block category
   */
  $('#block-category-remove-toggle').click(function() {
      var ids = {},
          i = 0;
      $('.categories-list li input:checked').each(function() {
          ids[i++] = $(this).val();
      });

      $('.categories-list li input:checked').closest('li').remove();

      $.ajax({
          type: "POST",
          url : ajaxurl,
          data: {
              action : 'bw_remove_category',
              options: {
                  'ids': ids
              }
          },
          success: function(data) {}
      });

      return false;
  });

  /**
   * Add to input for save
   */
  $('#brainwave-category .categories-list').on('change', 'input[type="checkbox"]', function() {
      var ids = '';

      $('.categories-list input[type="checkbox"]:checked').each(function() {
          ids += $(this).val() + ', ';
      });

      $('.wp-hidden-children .category-ids').val(ids.substring(0, ids.length - 2));
  });

  //Mailchimp validation
  $('body').on( 'change', '.variant', function ( e ) {
      if ( $(this).hasClass('mailchimp') ) {
          if ( ( $('.api_key').val() === '' ) || ( $('.list_id').val() === '' ) ) {
              $('.vc_btn').addClass('disabled');
              $('.vc_btn').attr('disabled', 'disabled');
          } else {
              $('.vc_btn').removeClass('disabled');
              $('.vc_btn').removeAttr('disabled');
          }
      } else {
          $('.vc_btn').removeClass('disabled');
          $('.vc_btn').removeAttr('disabled');
      }
  });

  $('body').on( 'change', '.api_key', function ( e ) {
      if ( ( $('.api_key').val() === '' ) || ( $('.list_id').val() === '' ) ) {
          $('.vc_btn').addClass('disabled');
          $('.vc_btn').attr('disabled', 'disabled');
          $(this).attr('placeholder', 'Must be entered');
      } else {
          $('.vc_btn').removeClass('disabled');
          $('.vc_btn').removeAttr('disabled');
      }
  });

  $('body').on( 'change', '.list_id', function ( e ) {
      if ( ( $('.api_key').val() === '' ) || ( $('.list_id').val() === '' ) ) {
          $('.vc_btn').addClass('disabled');
          $('.vc_btn').attr('disabled', 'disabled');
          $(this).attr('placeholder', 'Must be entered');
      } else {
          $('.vc_btn').removeClass('disabled');
          $('.vc_btn').removeAttr('disabled');
      }
  });

  // Features
  if ( typeof vc != 'undefined'  ) {
      if ( typeof vc.shortcode_view != 'undefined'  ) {
          window.FeatureView = vc.shortcode_view.extend( {
              adding_new_feature: false,
              events: {
                  'click .add_feature': 'addfeature',
                  'click > .vc_controls .column_delete, > .vc_controls .vc_control-btn-delete': 'deleteShortcode',
                  'click > .vc_controls .column_edit, > .vc_controls .vc_control-btn-edit': 'editElement',
                  'click > .vc_controls .column_clone,> .vc_controls .vc_control-btn-clone': 'clone'
              },
              render: function () {
                  window.FeatureView.__super__.render.call( this );
                  // check user role to add controls
                  if ( ! this.hasUserAccess() ) {
                      return this;
                  }
                  this.$content.sortable( {
                      axis: "y",
                      handle: "h3",
                      stop: function ( event, ui ) {
                          // IE doesn't register the blur when sorting
                          // so trigger focusout handlers to remove .ui-state-focus
                          ui.item.prev().triggerHandler( "focusout" );
                          $( this ).find( '> .wpb_sortable' ).each( function () {
                              var shortcode = $( this ).data( 'model' );
                              shortcode.save( { 'order': $( this ).index() } ); // Optimize
                          } );
                      }
                  } );
                  return this;
              },
              changeShortcodeParams: function ( model ) {
                  var params;

                  window.FeatureView.__super__.changeShortcodeParams.call( this, model );
                  params = model.get( 'params' );
              },
              changedContent: function ( view ) {
                  this.adding_new_feature = false;
              },
              addfeature: function ( e ) {
                  e.preventDefault();
                  // check user role to add controls
                  if ( ! this.hasUserAccess() ) {
                      return false;
                  }
                  this.adding_new_feature = true;
                  vc.shortcodes.create( {
                      shortcode: 'features',
                      params: { title: window.i18nLocale.section },
                      parent_id: this.model.id
                  } );
              },
              _loadDefaults: function () {
                  window.FeatureView.__super__._loadDefaults.call( this );
              }
          } );
      }

      // Icon Tabs
      if ( typeof vc.shortcode_view != 'undefined'  ) {
          window.IconTabsView = vc.shortcode_view.extend( {
              adding_new_feature: false,
              events: {
                  'click .add_icon_tab': 'addIconTab',
                  'click > .vc_controls .column_delete, > .vc_controls .vc_control-btn-delete': 'deleteShortcode',
                  'click > .vc_controls .column_edit, > .vc_controls .vc_control-btn-edit': 'editElement',
                  'click > .vc_controls .column_clone,> .vc_controls .vc_control-btn-clone': 'clone'
              },
              render: function () {
                  window.IconTabsView.__super__.render.call( this );
                  // check user role to add controls
                  if ( ! this.hasUserAccess() ) {
                      return this;
                  }
                  this.$content.sortable( {
                      axis: "y",
                      handle: "h3",
                      stop: function ( event, ui ) {
                          // IE doesn't register the blur when sorting
                          // so trigger focusout handlers to remove .ui-state-focus
                          ui.item.prev().triggerHandler( "focusout" );
                          $( this ).find( '> .wpb_sortable' ).each( function () {
                              var shortcode = $( this ).data( 'model' );
                              shortcode.save( { 'order': $( this ).index() } ); // Optimize
                          } );
                      }
                  } );
                  return this;
              },
              changeShortcodeParams: function ( model ) {
                  var params;

                  window.IconTabsView.__super__.changeShortcodeParams.call( this, model );
                  params = model.get( 'params' );
              },
              changedContent: function ( view ) {
                  this.adding_new_feature = false;
              },
              addIconTab: function ( e ) {
                  e.preventDefault();
                  // check user role to add controls
                  if ( ! this.hasUserAccess() ) {
                      return false;
                  }
                  this.adding_new_feature = true;
                  vc.shortcodes.create( {
                      shortcode: 'icon-tabs',
                      params: { title: window.i18nLocale.section },
                      parent_id: this.model.id
                  } );
              },
              _loadDefaults: function () {
                  window.IconTabsView.__super__._loadDefaults.call( this );
              }
          } );
      }

      if ( typeof vc.shortcode_view != 'undefined'  ) {
          window.LayersView = vc.shortcode_view.extend( {
              adding_new_feature: false,
              events: {
                  'click .add_layer': 'addLayer',
                  'click > .vc_controls .column_delete, > .vc_controls .vc_control-btn-delete': 'deleteShortcode',
                  'click > .vc_controls .column_edit, > .vc_controls .vc_control-btn-edit': 'editElement',
                  'click > .vc_controls .column_clone,> .vc_controls .vc_control-btn-clone': 'clone'
              },
              render: function () {
                  window.LayersView.__super__.render.call( this );
                  // check user role to add controls
                  if ( ! this.hasUserAccess() ) {
                      return this;
                  }
                  this.$content.sortable( {
                      axis: "y",
                      handle: "h3",
                      stop: function ( event, ui ) {
                          // IE doesn't register the blur when sorting
                          // so trigger focusout handlers to remove .ui-state-focus
                          ui.item.prev().triggerHandler( "focusout" );
                          $( this ).find( '> .wpb_sortable' ).each( function () {
                              var shortcode = $( this ).data( 'model' );
                              shortcode.save( { 'order': $( this ).index() } ); // Optimize
                          } );
                      }
                  } );
                  return this;
              },
              changeShortcodeParams: function ( model ) {
                  var params;

                  window.LayersView.__super__.changeShortcodeParams.call( this, model );
                  params = model.get( 'params' );
              },
              changedContent: function ( view ) {
                  this.adding_new_feature = false;
              },
              addLayer: function ( e ) {
                  e.preventDefault();
                  // check user role to add controls
                  if ( ! this.hasUserAccess() ) {
                      return false;
                  }
                  this.adding_new_feature = true;
                  vc.shortcodes.create( {
                      shortcode: 'layers-img',
                      params: { title: window.i18nLocale.section },
                      parent_id: this.model.id
                  } );
              },
              _loadDefaults: function () {
                  window.LayersView.__super__._loadDefaults.call( this );
              }
          } );
      }

      if ( typeof vc.shortcode_view != 'undefined'  ) {
          window.PricingView = vc.shortcode_view.extend( {
              adding_new_feature: false,
              events: {
                  'click .add_pricing': 'addprice',
                  'click > .vc_controls .column_delete, > .vc_controls .vc_control-btn-delete': 'deleteShortcode',
                  'click > .vc_controls .column_edit, > .vc_controls .vc_control-btn-edit': 'editElement',
                  'click > .vc_controls .column_clone,> .vc_controls .vc_control-btn-clone': 'clone'
              },
              render: function () {
                  window.PricingView.__super__.render.call( this );
                  // check user role to add controls
                  if ( ! this.hasUserAccess() ) {
                      return this;
                  }
                  this.$content.sortable( {
                      axis: "y",
                      handle: "h3",
                      stop: function ( event, ui ) {
                          // IE doesn't register the blur when sorting
                          // so trigger focusout handlers to remove .ui-state-focus
                          ui.item.prev().triggerHandler( "focusout" );
                          $( this ).find( '> .wpb_sortable' ).each( function () {
                              var shortcode = $( this ).data( 'model' );
                              shortcode.save( { 'order': $( this ).index() } ); // Optimize
                          } );
                      }
                  } );
                  return this;
              },
              changeShortcodeParams: function ( model ) {
                  var params;

                  window.FeatureView.__super__.changeShortcodeParams.call( this, model );
                  params = model.get( 'params' );
              },
              changedContent: function ( view ) {
                  this.adding_new_feature = false;
              },
              addprice: function ( e ) {
                  e.preventDefault();
                  // check user role to add controls
                  if ( ! this.hasUserAccess() ) {
                      return false;
                  }
                  this.adding_new_price = true;
                  vc.shortcodes.create( {
                      shortcode: 'pricing',
                      params: { title: window.i18nLocale.section },
                      parent_id: this.model.id
                  } );
              },
              _loadDefaults: function () {
                  window.PricingView.__super__._loadDefaults.call( this );
              }
          } );
      }

      // Services
      if ( typeof vc.shortcode_view != 'undefined'  ) {
          window.ServiceView = vc.shortcode_view.extend( {
              adding_new_Service: false,
              events: {
                  'click .add_service': 'addService',
                  'click > .vc_controls .column_delete, > .vc_controls .vc_control-btn-delete': 'deleteShortcode',
                  'click > .vc_controls .column_edit, > .vc_controls .vc_control-btn-edit': 'editElement',
                  'click > .vc_controls .column_clone,> .vc_controls .vc_control-btn-clone': 'clone'
              },
              render: function () {
                  window.ServiceView.__super__.render.call( this );
                  // check user role to add controls
                  if ( ! this.hasUserAccess() ) {
                      return this;
                  }
                  this.$content.sortable( {
                      axis: "y",
                      handle: "h3",
                      stop: function ( event, ui ) {
                          // IE doesn't register the blur when sorting
                          // so trigger focusout handlers to remove .ui-state-focus
                          ui.item.prev().triggerHandler( "focusout" );
                          $( this ).find( '> .wpb_sortable' ).each( function () {
                              var shortcode = $( this ).data( 'model' );
                              shortcode.save( { 'order': $( this ).index() } ); // Optimize
                          } );
                      }
                  } );
                  return this;
              },
              changeShortcodeParams: function ( model ) {
                  var params;

                  window.ServiceView.__super__.changeShortcodeParams.call( this, model );
                  params = model.get( 'params' );
              },
              changedContent: function ( view ) {
                  this.adding_new_Service = false;
              },
              addService: function ( e ) {
                  e.preventDefault();
                  // check user role to add controls
                  if ( ! this.hasUserAccess() ) {
                      return false;
                  }
                  this.adding_new_service = true;
                  vc.shortcodes.create( {
                      shortcode: 'services',
                      params: { title: window.i18nLocale.section },
                      parent_id: this.model.id
                  } );
              },
              _loadDefaults: function () {
                  window.ServiceView.__super__._loadDefaults.call( this );
              }
          } );
      }

      //Slider
      if ( typeof vc.shortcode_view != 'undefined'  ) {
          window.SliderView = vc.shortcode_view.extend( {
              events: {
                  'click > .vc_controls .column_delete, > .vc_controls .vc_control-btn-delete': 'deleteShortcode',
                  'click > .vc_controls .column_edit, > .vc_controls .vc_control-btn-edit': 'editElement',
                  'click > .vc_controls .column_clone,> .vc_controls .vc_control-btn-clone': 'clone',
                  'click > .vc_controls [data-vc-control="add"]': 'addElement',
                  'click > .wpb_element_wrapper > .vc_empty-container': 'addToEmpty'
              },
              addToEmpty: function ( e ) {
                  e.preventDefault();
                  if ( $( e.target ).hasClass( 'vc_empty-container' ) ) {
                      this.addElement( e );
                  }
              },
              deleteShortcode: function ( e ) {
                  var parent_id = this.model.get( 'parent_id' ),
                      parent;
                  if ( _.isObject( e ) ) {
                      e.preventDefault();
                  }
                  var answer = confirm( window.i18nLocale.press_ok_to_delete_section );
                  if ( answer !== true ) {
                      return false;
                  }
                  this.model.destroy();
                  if ( parent_id && ! vc.shortcodes.where( { parent_id: parent_id } ).length ) {
                      parent = vc.shortcodes.get( parent_id );
                      if ( ! _.contains( [
                              'vc_column',
                              'vc_column_inner'
                          ], parent.get( 'shortcode' ) ) ) {
                          parent.destroy();
                      }
                  } else if ( parent_id ) {
                      parent = vc.shortcodes.get( parent_id );
                      if ( parent && parent.view && parent.view.setActiveLayoutButton ) {
                          parent.view.setActiveLayoutButton();
                      }
                  }
              }
          } );
      }

      //Animate
      if ( typeof vc.shortcode_view != 'undefined'  ) {
          window.AnimateView = vc.shortcode_view.extend( {
              events: {
                  'click > .vc_controls .column_delete, > .vc_controls .vc_control-btn-delete': 'deleteShortcode',
                  'click > .vc_controls .column_edit, > .vc_controls .vc_control-btn-edit': 'editElement',
                  'click > .vc_controls .column_clone,> .vc_controls .vc_control-btn-clone': 'clone',
                  'click > .vc_controls [data-vc-control="add"]': 'addElement',
                  'click > .wpb_element_wrapper > .vc_empty-container': 'addToEmpty'
              },
              addToEmpty: function ( e ) {
                  e.preventDefault();
                  if ( $( e.target ).hasClass( 'vc_empty-container' ) ) {
                      this.addElement( e );
                  }
              },
              deleteShortcode: function ( e ) {
                  var parent_id = this.model.get( 'parent_id' ),
                      parent;
                  if ( _.isObject( e ) ) {
                      e.preventDefault();
                  }
                  var answer = confirm( window.i18nLocale.press_ok_to_delete_section );
                  if ( answer !== true ) {
                      return false;
                  }
                  this.model.destroy();
                  if ( parent_id && ! vc.shortcodes.where( { parent_id: parent_id } ).length ) {
                      parent = vc.shortcodes.get( parent_id );
                      if ( ! _.contains( [
                              'vc_column',
                              'vc_column_inner'
                          ], parent.get( 'shortcode' ) ) ) {
                          parent.destroy();
                      }
                  } else if ( parent_id ) {
                      parent = vc.shortcodes.get( parent_id );
                      if ( parent && parent.view && parent.view.setActiveLayoutButton ) {
                          parent.view.setActiveLayoutButton();
                      }
                  }
              }
          } );
      }
  }


});
