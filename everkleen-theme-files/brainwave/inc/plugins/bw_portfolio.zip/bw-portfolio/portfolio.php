<?php
/**
 * Plugin Name: BW Portfolio
 * Plugin URI:  http://scientecraft.com/plugins/bw-portfolio
 * Description: Portfolio and shortcodes from BrainWave theme for WordPress.
 * Version:     0.0.8
 * Author:      ScienteCraft
 * Author URI:  http://scientecraft.com
 * Text Domain: bw-portfolio
 *
 * @package   BWPortfolio
 * @version   0.0.8
 * @author    ScienteCraft <scientecraft.info@gmail.com>
 * @copyright Copyright (c) 2015, ScienteCraft
 * @license   http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 *
 * Copyright 2015  ScienteCraft  (email: scientecraft.info@gmail.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

function bw_get_animations() {
$animations = '{
  "none": {
    "---": true
  },

  "attention_seekers": {
    "bounce": true,
    "flash": true,
    "pulse": true,
    "rubberBand": true,
    "shake": true,
    "swing": true,
    "tada": true,
    "wobble": true,
    "jello": true
  },

  "bouncing_entrances": {
    "bounceIn": true,
    "bounceInDown": true,
    "bounceInLeft": true,
    "bounceInRight": true,
    "bounceInUp": true
  },

  "bouncing_exits": {
    "bounceOut": true,
    "bounceOutDown": true,
    "bounceOutLeft": true,
    "bounceOutRight": true,
    "bounceOutUp": true
  },

  "fading_entrances": {
    "fadeIn": true,
    "fadeInDown": true,
    "fadeInDownBig": true,
    "fadeInLeft": true,
    "fadeInLeftBig": true,
    "fadeInRight": true,
    "fadeInRightBig": true,
    "fadeInUp": true,
    "fadeInUpBig": true
  },

  "fading_exits": {
    "fadeOut": true,
    "fadeOutDown": true,
    "fadeOutDownBig": true,
    "fadeOutLeft": true,
    "fadeOutLeftBig": true,
    "fadeOutRight": true,
    "fadeOutRightBig": true,
    "fadeOutUp": true,
    "fadeOutUpBig": true
  },

  "flippers": {
    "flip": true,
    "flipInX": true,
    "flipInY": true,
    "flipOutX": true,
    "flipOutY": true
  },

  "lightspeed": {
    "lightSpeedIn": true,
    "lightSpeedOut": true
  },

  "rotating_entrances": {
    "rotateIn": true,
    "rotateInDownLeft": true,
    "rotateInDownRight": true,
    "rotateInUpLeft": true,
    "rotateInUpRight": true
  },

  "rotating_exits": {
    "rotateOut": true,
    "rotateOutDownLeft": true,
    "rotateOutDownRight": true,
    "rotateOutUpLeft": true,
    "rotateOutUpRight": true
  },

  "specials": {
    "hinge": true,
    "rollIn": true,
    "rollOut": true
  },

  "zooming_entrances": {
    "zoomIn": true,
    "zoomInDown": true,
    "zoomInLeft": true,
    "zoomInRight": true,
    "zoomInUp": true
  },

  "zooming_exits": {
    "zoomOut": true,
    "zoomOutDown": true,
    "zoomOutLeft": true,
    "zoomOutRight": true,
    "zoomOutUp": true
  },

  "sliding_entrances": {
    "slideInDown": true,
    "slideInLeft": true,
    "slideInRight": true,
    "slideInUp": true
  },

  "sliding_exits": {
    "slideOutDown": true,
    "slideOutLeft": true,
    "slideOutRight": true,
    "slideOutUp": true
  }
}
';
$animations =  get_object_vars( json_decode( $animations ) );
$new_animations = array();
foreach ( $animations as $animation ) {
  $animation = get_object_vars( $animation );
  foreach ($animation as $key => $value) {
    $new_animations[ $key ] = $key;
  }
}

return $new_animations;
}

 $brainwave_includes = array(
   // Shortcodes
   'shortcodes/promo-photo.php',               // Promo Photo VSComposer Extension
   'shortcodes/skills.php',                    // Skills VSComposer Extension
   'shortcodes/service.php',                   // Services VSComposer Extension
   'shortcodes/indent.php',                    // Indents VSComposer Extension
   'shortcodes/buttons.php',                   // Buttons VSComposer Extension
   'shortcodes/portfolio.php',                 // Portfolio VSComposer Extension
   'shortcodes/featured-ico.php',              // Featured Icons VSComposer Extension
   'shortcodes/layers-image.php',              // Animated Images VSComposer Extension
   'shortcodes/counter.php',                   // Counter VSComposer Extension
   'shortcodes/contact.php',                   // Contacts VSComposer Extension
   'shortcodes/map.php',                       // Map VSComposer Extension
   'shortcodes/slider.php',                    // Slider VSComposer Extension
   'shortcodes/image-slide.php',               // Image Slide VSComposer Extension
   'shortcodes/team-slide.php',                // Team Slide VSComposer Extension
   'shortcodes/video-slide.php',               // Video Slide VSComposer Extension
   'shortcodes/testimonials-slide.php',        // Testimonials Slide VSComposer Extension
   'shortcodes/clients-slide.php',             // Testimonials Slide VSComposer Extension
   'shortcodes/custom-slide.php',              // Custom Content Slide VSComposer Extension
   'shortcodes/project-details.php',           // Portfolio Project Details VSComposer Extension
   'shortcodes/subscribe-form.php',            // Subscribe VSComposer Extension
   'shortcodes/text-rotator.php',              // Text Rotator VSComposer Extension
   'shortcodes/pricing.php',                   // Pricing VSComposer Extension
   'shortcodes/animate.php',                   // Animate VSComposer Extension
   'shortcodes/icons.php',                     // Icons for vc_iconpicker
   'shortcodes/icon-tabs.php',                 // Icons acordion
   'shortcodes/icon-block.php',                // Text with icon
	 'shortcodes/gallery.php',                   // Custom [gallery] modifications

 );

 foreach ( $brainwave_includes as $file ) {
   $filepath = plugin_dir_path( __FILE__ ) . $file;
   if ( ! file_exists( $filepath )  ) :
     trigger_error( sprintf( __( 'Error locating %s for inclusion', 'bw-portfolio' ), $file ), E_USER_ERROR );
   endif;
   require_once $filepath;
 }
 unset( $file, $filepath );


 require_once plugin_dir_path( __FILE__) . 'helpers/category.php';
 require_once plugin_dir_path( __FILE__) . 'helpers/MailChimp.php';

	function bw_register_portfolio_posts() {
		$args = array(
			'label' 	=> __( 'Portfolio', 'bw-portfolio' ),
			'public' 	=> true,
			'supports' 	=> array(
			 	'title',
			 	'thumbnail',
			 	'editor',
			)
		);
		register_post_type( 'portfolio', $args );
	}
	add_action( 'init', 'bw_register_portfolio_posts' );

	function bw_template_include( $template ) {
    global $brainwave;
	  if ( is_single() && ( get_post_type() == 'portfolio' ) ) {

      $has_template = locate_template( 'portfolio-project.php' );
      $template = plugin_dir_path( __FILE__ ) . 'template/portfolio-project.php';
      if ( ! empty( $brainwave['portfolio_popup'] ) ) {
          if ( $brainwave['portfolio_popup'] ) {
            $has_template = locate_template( 'portfolio-project-popup.php' );
      			$template = plugin_dir_path( __FILE__ ) . 'template/portfolio-project-popup.php';
          }
      }

			return $has_template ? $has_template : $template;
		} else {
			return $template;
		}

	}
	add_filter( 'template_include', 'bw_template_include', 5 );

	// Custom meta boxes add
	function bw_add_portfolio_meta() {
	  add_meta_box( 'block_category', __( 'Categories', 'bw-portfolio' ), array( 'BW_Block_Categories', 'categoryMetaBox' ), 'portfolio', 'side', 'default' );
		add_meta_box( 'masonry_view',  __( 'Masonry Size', 'bw-portfolio' ), 'bw_masonry_size_options', 'portfolio', 'side' );
	}
	add_action( 'add_meta_boxes', 'bw_add_portfolio_meta' );

	// Masonry in Portfolio output
	function bw_masonry_size_options(){
	  global $post;
	  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) : return $post_id; endif;
	  $size = get_post_meta( $post->ID, 'masonry_view', true );
	?>
	  <div class="masonry-size">
	    <select id="size_values" name="masonry_view">
	      <option <?php if ( $size == '1x1' ) : echo ' selected '; endif; ?> value="1x1">1x1</option>
	      <option <?php if ( $size == '2x2' ) : echo ' selected '; endif; ?> value="2x2">2x2</option>
	    </select>
	  </div>
	<?php
	}

	// Saving meta
	function bw_save_portfolio_meta() {
	  global $post;
		if ( isset( $_POST['block_categories'] ) ) {
      update_post_meta( $post->ID, 'block_categories', sanitize_text_field( $_POST['block_categories'] ) );
    }
		if ( isset( $_POST['masonry_view'] ) ) {
      update_post_meta( $post->ID, "masonry_view", $_POST["masonry_view"] );
    }
	}
	add_action( 'save_post', 'bw_save_portfolio_meta' );

	//Styles and scripts enqueue
	function bw_enqueue_potrfolio_scripts() {
		//Scripts
		wp_enqueue_script( 'wow', plugin_dir_url( __FILE__ ) . 'js/wow.js' , array( 'jquery' ), null, true );
		wp_enqueue_script( 'jquery_magnific_popup', plugin_dir_url( __FILE__ ) . 'js/jquery.magnific-popup.js' , array( 'jquery' ), null, true );
		wp_enqueue_script( 'jquery_inview', plugin_dir_url( __FILE__ ) . 'js/jquery.inview.js' , array( 'jquery' ), null, true );
		wp_enqueue_script( 'isotope', plugin_dir_url( __FILE__ ) . 'js/isotope.js' , array( 'jquery' ), null, true );
		wp_enqueue_script( 'owl_carousel', plugin_dir_url( __FILE__ ) . 'js/owl.carousel.js' , array( 'jquery' ), null, true );
		wp_enqueue_script( 'bw_map', 'https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true&ver=v=3.exp&signed_in=true', array( 'jquery' ), null, true );

		wp_register_script( 'bw_main', plugin_dir_url( __FILE__ ) . 'js/main.js', array( 'jquery' ) );
	  $ajax_url = array(
	    'ajaxurl' => admin_url('admin-ajax.php'),
	  );
	  wp_localize_script( 'bw_main', 'helpers', $ajax_url );
	  wp_enqueue_script( 'bw_main' );

		//Styles
		wp_enqueue_style( 'bw_font_awesome' , plugin_dir_url( __FILE__ ) . 'css/font-awesome.css', false, null);
		wp_enqueue_style( 'bw_etline' , plugin_dir_url( __FILE__ ) . 'css/et-line.css', false, null);
		wp_enqueue_style( 'bw_simple_line' , plugin_dir_url( __FILE__ ) . 'css/simple-line-icons.css', false, null);
		wp_enqueue_style( 'bw_elegant' , plugin_dir_url( __FILE__ ) . 'css/elegant-font.css', false, null);
		wp_enqueue_style( 'bw_owl_carousel_style' , plugin_dir_url( __FILE__ ) . 'css/owl.carousel.css', false, null);
		wp_enqueue_style( 'bw_main_style' , plugin_dir_url( __FILE__ ) . 'css/main.css', false, null);
	}
	add_action( 'wp_enqueue_scripts', 'bw_enqueue_potrfolio_scripts', 105 );

	// Admin script enqueue
	function bw_enqueue_potrfolio_admin_scripts() {
		//Admin script
		wp_enqueue_script( 'bw_script', plugin_dir_url( __FILE__ ) . 'js/script.js' , array( 'jquery' ), null, true );
	}
	add_action( 'admin_enqueue_scripts', 'bw_enqueue_potrfolio_admin_scripts', 100 );

	// Portfolio Categories
	function bw_get_portfolio_categories() {
	  global $wpdb;
	  $table_name = $wpdb->prefix . 'bw_block_categories';
	  $result = $wpdb->get_results( "SELECT id, name FROM " . $wpdb->prefix . "bw_block_categories WHERE block_type = 'portfolio'" );
	  return $result;
	}

	// Portfolio Categories for post
	function bw_get_portfolio_post_categories( $post ) {
	  $cat_ids = get_post_meta( $post->ID, 'block_categories', true ) . ',';
	  return $cat_ids;
	}

  // Subscribe to Database
	add_action( 'wp_ajax_bw_subscribe', 'bw_subscribe' );
	add_action( 'wp_ajax_nopriv_bw_subscribe', 'bw_subscribe' );
	function bw_subscribe() {
	  global $wpdb;
	  ob_start();
	  $subscriber = $_POST['subscriber'];
	  $table_name = $wpdb->prefix . 'bw_subscribers';
	  if ( filter_var( $subscriber, FILTER_VALIDATE_EMAIL) ):
	    if ( ! ( $wpdb->get_results("SELECT * FROM `$table_name` WHERE `subscriber_email` = '$subscriber' ") ) ) :
	      $wpdb->insert( $table_name, array( 'subscriber_email' => $subscriber ) );
	      echo 'You have successfully subscribed';
	    else :
	      echo 'Error: You have already subscribed';
	    endif;
	  else :
	    echo 'Error: wrong email format';
	  endif;
	  echo ob_get_clean();
	  wp_die();
	}

  // Subscribe to Database
	add_action( 'wp_ajax_bw_get_portfolio_content', 'bw_get_portfolio_content' );
	add_action( 'wp_ajax_nopriv_bw_get_portfolio_content', 'bw_get_portfolio_content' );
	function bw_get_portfolio_content() {
    global $post;
    $temp_post = $post;
    $id = $_POST['id'];

    $post = get_post($id);
    setup_postdata( $post );
    $query = new WP_Query( array(
      'post_type'       => 'portfolio',
      'page_id' => $id,
    ) );
	  ob_start();
    if ( $query->have_posts() ) :
  		while ( $query->have_posts() ) : $query->the_post();
			   the_content();
		  endwhile;
	 endif;
	  echo ob_get_clean();
	  wp_die();
	}

	// Remove subscriber from database
	add_action( 'wp_ajax_bw_remove_subscriber', 'bw_remove_subscriber' );
	add_action( 'wp_ajax_nopriv_bw_remove_subscriber', 'bw_remove_subscriber' );
	function bw_remove_subscriber() {
	  global $wpdb;
	  $id = $_POST['id'];
	  $table_name = $wpdb->prefix . 'bw_subscribers';
	  $wpdb->delete( $table_name, array( 'ID' => $id ) );
	  wp_die();
	}

	// Subscribe to MailChimp list
	add_action( 'wp_ajax_bw_subscribe_mailchimp', 'bw_subscribe_mailchimp' );
	add_action( 'wp_ajax_nopriv_bw_subscribe_mailchimp', 'bw_subscribe_mailchimp' );
	function bw_subscribe_mailchimp() {
	  ob_start();
	  if ( ! strpos( $_POST['mcapi'], '-') ) {
	    echo ('Not Valid Mailchimp API Key');
	    wp_die();
	  }
	  $MailChimp = new BW_MailChimp( $_POST['mcapi'] );
	  $lists = $MailChimp->call( 'lists/list' );
	  $data = $lists['data'];
	  $email = strtolower( $_POST['subscriber'] );
	  $msg1 = 'Invalid email format';
	  $msg2 = 'You have successfully subscribed';
	  if ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
	      echo $msg1;
	      wp_die();
	  } else {
	    foreach ( $data as $key => $value ) {
	      if ( $value['id'] == $_POST['mclistid'] ) {
	        $result = $MailChimp->call( 'lists/subscribe', array(
	          'id'                => $value['id'],
	          'email'             => array( 'email' => $email ),
	          'merge_vars'        => array( 'FNAME' => '', 'LNAME' => '' ),
	          'double_optin'      => false,
	          'replace_interests' => false,
	          'send_welcome'      => false,
	        ) );
	        if ( ! empty( $result['error'] ) ) {
	          echo $result['error'];
	          wp_die();
	        }
	      }
	    }
	    echo ( $msg2 );
	    wp_die();
	  }
	  echo ob_get_clean();
	}

	//On plugin activation
	function bw_activation() {

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		global $wpdb;
		// Create table for subscribers
		$sql = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . "bw_subscribers (
			id int(11) NOT NULL AUTO_INCREMENT,
			subscriber_email varchar(255) DEFAULT NULL,
			UNIQUE KEY id (id)
		) CHARSET=utf8;";
		$wpdb->query( $sql );

		// Crate table for categories
		$sql = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . "bw_block_categories (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			block_type tinytext NOT NULL,
			name tinytext NOT NULL,
			slug tinytext NOT NULL,
			UNIQUE KEY id (id)
			) CHARSET=utf8;";
		$wpdb->query( $sql );

		// Create three test categories
		$count_cat = $wpdb->get_results("SELECT COUNT(*) FROM " . $wpdb->prefix . "bw_block_categories");
		$count_cat = get_object_vars($count_cat[0]);
		$count_cat = (int) $count_cat["COUNT(*)"];

		if ( $count_cat === 0 ) {
			// Photography
			$wpdb->insert(
				$wpdb->prefix . 'bw_block_categories',
				array(
					'id' => 1,
					'block_type' => 'portfolio',
					'name' => 'Photography',
					'slug' => 'photography',
				),
				array( '%d', '%s', '%s', '%s' )
			);
			// Design
			$wpdb->insert(
				$wpdb->prefix . 'bw_block_categories',
				array(
					'id' => 2,
					'block_type' => 'portfolio',
					'name' => 'Design',
					'slug' => 'design',
				),
				array( '%d', '%s', '%s', '%s' )
			);
			// Branding
			$wpdb->insert(
				$wpdb->prefix . 'bw_block_categories',
				array(
					'id' => 3,
					'block_type' => 'portfolio',
					'name' => 'Branding',
					'slug' => 'branding',
				),
				array( '%d', '%s', '%s', '%s' )
			);

		}

	}
	register_activation_hook( __FILE__, 'bw_activation' );
