=== Custom Content Portfolio ===
Contributors: ace_ok
Author link: http://scientecraft.com
Tags: portfolio, images, image, post type, shortcode
Requires at least: 4.3
Stable tag: 0.0.8
License: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

Portfolio and shortcodes for BrainWave theme.

== Description ==

Plugin for BrainWave theme correct work. Contains useful portfolio post type with template file, and some author's shortcodes.
### Features

* Portfolio: Custom portfolio post type.
* Categories: Categorize portfolio posts.
* 30 useful shortcodes, such as [portfolio] for portfolio output, or slider for galleries etc.

### Professional Support

If You buy it with BrainWave theme then You could get support on support.scientecraft.com

== Installation ==

1. Upload `bw-portfolio` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Enjoy.

== Changelog ==

0.0.1: Initial release;
0.0.2: Few new shortcodes added, animation bug fixed;
0.0.3: Pricing shortcode button text setting added
0.0.4: All wordpress filesystem functions changed to custom for more compability
0.0.5: Fixed portfolio-filter bug[names with spaces doesn't works]
0.0.6: MailChimp class name conflict fixed; Portfolio shortcode popup variant added; Services shortcode link field added; Features shortcode link field added; Clients link target added;
0.0.7: Portfolio shortcode: added possibility to show posts from one category
0.0.8: Team slide shortcode: removed deprecated width/height from image
