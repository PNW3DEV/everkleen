<?php

add_shortcode( 'animate', 'bw_animate_shortcode' );
function bw_animate_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'animation'   => '',
    'delay'       => '',
  ), $atts ) );
  $delay      = ( isset( $atts['delay'] ) ) ? $atts['delay'] : '';
  $animation  = ( isset( $atts['animation'] ) ) ? $atts['animation'] . ' wow' : '';

  ob_start();
  echo '<div class="' . esc_attr( $animation ) . '" alt="" data-wow-delay="' . esc_attr( $delay ) . 's">';
  echo apply_filters('the_content', $content );
  echo '<div>';
  return ob_get_clean();
}

add_action( 'vc_before_init', 'bw_vc_animate_shortcode' );
function bw_vc_animate_shortcode() {
  $new_animations = bw_get_animations();

  vc_map( array(
    "name"                      => __( "Animate Content", "brainwave" ),
    "base"                      => "animate",
    "category"                  => __( "Content", "brainwave" ),
    "content_element"           => true,
    'allowed_container_element' => 'vc_row',
    "is_container"              => true,
    "params"                    => array(
      array(
        "type"        => "textfield",
        "heading"     => __( "Delay", "brainwave" ),
        "param_name"  => "delay",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Animation", "brainwave" ),
        "param_name"  => "animation",
        "value"       => $new_animations,
      ),
    ),
    'custom_markup'   => '
      <div class="vc_container_for_children">
      </div>
      <div class="vc_empty-container">
      </div>
    ',
    'js_view'         => 'AnimateView',

  ) );
}
?>
