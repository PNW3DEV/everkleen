<?php

function bw_buttons_shortcode( $atts, $content = null ) {
  extract( shortcode_atts( array(
    'button_text'       => '',
    'button_size'       => '',
    'button_type'       => '',
    'button_link'       => '',
    'icon_lib'          => '',
    'icon_fontawesome'  => '',
    'icon_elegant'      => '',
    'icon_etline'       => '',
    'icon_simpleline'   => '',
    'animation'         => '',
    'delay'             => '',
    'after_page'        => '',
    'css'               => '',
  ), $atts ) );

  $size = ( ! empty( $atts['button_size'] ) ) ? $atts['button_size'] : 'btn';
  $type = ( ! empty( $atts['button_type'] ) ) ? $atts['button_type'] : 'btn-default';
  $text = ( ! empty( $atts['button_text'] ) ) ? $atts['button_text'] : '';
  $link = ( ! empty( $atts['button_link'] ) ) ? $atts['button_link'] : '';

  $delay      = ( ! empty( $atts['delay'] ) ) ? $atts['delay'] : '0';
  $animation  = ( ! empty( $atts['animation'] ) ) ? $atts['animation'] . ' wow' : '';

  switch ( $icon_lib ) {
    case 'etline':
      $icon   = ( ! empty( $atts['icon_etline'] ) ) ? $atts['icon_etline'] : '';
      break;
    case 'elegant':
      $icon   = ( ! empty( $atts['icon_elegant'] ) ) ? $atts['icon_elegant'] : '';
      break;
    case 'simpleline':
      $icon   = ( ! empty( $atts['icon_simpleline'] ) ) ? $atts['icon_simpleline'] : '';
      break;
    default:
      $icon   = ( ! empty( $atts['icon_fontawesome'] ) ) ? $atts['icon_fontawesome'] : '';
      break;
  }

  $css_class = '';

  $output = '';
  if ( isset( $atts['css'] ) ) :
    $css = $atts['css'];
    $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
    $output .= '<style type="text/css">';
    $output .= $css;
    $output .= '</style>';
  endif;

  if ( ! empty( $link ) ) {
    $output .= '<a class="btn ' . esc_attr( $type ) . ' ' . esc_attr( $size ) . ' ' . esc_attr( $css_class ) . ' ' . esc_attr( $animation ) . '" data-wow-delay="' . esc_attr( $delay ) . 's" href="' . esc_url( $link ) . '" >';
  } else {
    $output .= '<div class="btn ' . esc_attr( $type ) . ' ' . esc_attr( $size ) . ' ' . esc_attr( $css_class ) . ' ' . esc_attr( $animation ) . '" data-wow-delay="' . esc_attr( $delay ) . 's">';
  }

  $output .= ( ! empty( $icon ) ) ? '<span aria-hidden="true" class="' . esc_attr( $icon ) . '"></span>&nbsp;' : '';
  $output .= $text;

  if ( ! empty( $link ) ) {
    $output .= '</a>
    ';
  } else {
    $output .= '</div>
    ';
  }

  return $output;
}
add_shortcode( 'buttons', 'bw_buttons_shortcode' );

function bw_vc_buttons_shortcode() {
  $new_animations = bw_get_animations();

  vc_map( array(
    "name"            => __( "Buttons", "brainwave" ),
    "base"            => "buttons",
    "class"           => "",
    "category"        => __( "Content", "brainwave" ),
    "content_element" => true,
    "params"          => array(
      array(
        "type"        => "textfield",
        "holder"      => "div",
        "class"       => "button-text",
        "heading"     => __( "Text", "brainwave" ),
        "param_name"  => "button_text",
        "value"       => "",
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Link", "brainwave" ),
        "param_name"  => "button_link",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Size", "brainwave" ),
        "param_name"  => "button_size",
        "value"       => array(
          'Normal'      => 'btn',
          'Large'       => 'btn-lg',
          'Small'       => 'btn-sm',
          'Extra Small' => 'btn-xs',
        ),
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Type", "brainwave" ),
        "param_name"  => "button_type",
        "value"       => array(
          'Default' => 'btn-default',
          'Primary' => 'btn-primary',
          'Success' => 'btn-success',
          'Info'    => 'btn-info',
          'Danger'  => 'btn-danger',
          'Warning' => 'btn-warning',
          'Link'    => 'btn-link',
        ),
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Icon Library", "brainwave" ),
        "param_name"  => "icon_lib",
        "value"       => array(
          'Font Awesome' => 'fontawesome',
          'Et Line' => 'etline',
          'Simple Line' => 'simpleline',
          'Elegant' => 'elegant',
        ),
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_elegant',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'elegant',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'elegant',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_etline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'etline',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'etline',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_simpleline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'simpleline',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'simpleline',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_fontawesome',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'fontawesome',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'fontawesome',
        ),
        'value'       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Delay", "brainwave" ),
        "param_name"  => "delay",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Animation", "brainwave" ),
        "param_name"  => "animation",
        "value"       => $new_animations,
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
      array(
        'type'        => 'css_editor',
        'heading'     => __( 'CSS box', 'brainwave' ),
        'param_name'  => 'css',
        'group'       => __( 'Design Options', 'brainwave' )
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_buttons_shortcode' );

?>
