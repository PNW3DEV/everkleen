<?php

function bw_client_slide_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'target'      => '',
    'client_url'  => '',
    'client_logo' => '',
  ), $atts ) );
  $target   = ( ! empty( $atts['target'] ) ) ? "_blank" : "_self";
  $client_url   = ( ! empty( $atts['client_url'] ) ) ? $atts['client_url'] : '#';
  $client_logo  = ( ! empty( $atts['client_logo'] ) ) ? $atts['client_logo'] : '';
  ob_start();
?>
  <a href="<?php echo esc_url( $client_url ); ?>" target="<?php echo esc_attr( $target ); ?>" class="carousel-item">
    <?php echo wp_get_attachment_image( $client_logo ); ?>
  </a>
<?php
  return ob_get_clean();
}
add_shortcode( 'client_slide', 'bw_client_slide_shortcode' );

function bw_vc_client_slide_shortcode() {
  vc_map( array(
    "name"            => __( "Client Slide", "brainwave" ),
    "base"            => "client_slide",
    "category"        => __( "Content", "brainwave" ),
    "content_element" => true,
    "params"          => array(
      array(
        'type'        => 'textfield',
        'heading'     => __( 'Url', 'brainwave' ),
        'param_name'  => 'client_url',
        'value'       => '',
      ),
      array(
        'type'        => 'checkbox',
        'heading'     => __( 'Open in new window/tab', 'brainwave' ),
        'param_name'  => 'target',
        'value'       => '',
      ),
      array(
        'type'        => 'attach_image',
        'heading'     => __( 'Logo', 'brainwave' ),
        'param_name'  => 'client_logo',
        'value'       => '',
      ),
    ),
  ) );
}
add_action( 'vc_before_init', 'bw_vc_client_slide_shortcode' );

?>
