<?php

function bw_contact_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'text'              => '',
    'desc'              => '',
    'icon_lib'          => '',
    'icon_fontawesome'  => '',
    'icon_elegant'      => '',
    'icon_etline'       => '',
    'icon_simpleline'   => '',
    'animation'         => '',
    'delay'             => '',
    'after_page'        => '',
    'css'               => '',
  ), $atts ) );
  $text       = ( ! empty( $atts['text'] ) ) ? $atts['text'] : '';
  $desc       = ( ! empty( $atts['desc'] ) ) ? $atts['desc'] : '';
  $delay      = ( ! empty( $atts['delay'] ) ) ? $atts['delay'] : '0';
  $animation  = ( ! empty( $atts['animation'] ) ) ? $atts['animation'] . ' wow' : '';

  switch ( $icon_lib ) {
    case 'etline':
      $icon   = ( ! empty( $atts['icon_etline'] ) ) ? $atts['icon_etline'] : '';
      break;
    case 'elegant':
      $icon   = ( ! empty( $atts['icon_elegant'] ) ) ? $atts['icon_elegant'] : '';
      break;
    case 'simpleline':
      $icon   = ( ! empty( $atts['icon_simpleline'] ) ) ? $atts['icon_simpleline'] : '';
      break;
    default:
      $icon   = ( ! empty( $atts['icon_fontawesome'] ) ) ? $atts['icon_fontawesome'] : '';
      break;
  }
  $css_class = '';
  ob_start();
  if ( isset( $atts['css'] ) ) :
    $css = $atts['css'];
    $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
?>
    <style type="text/css">
      <?php echo $css; ?>
    </style>
<?php endif; ?>

  <div class="contact-item <?php echo ( ! empty( $css ) ) ? esc_attr( $css_class ) : ''; ?>">
    <div class="icon-wrapper">
      <div class="icon-box">
        <i class="<?php echo esc_attr( $icon ); ?>"></i>
      </div>
    </div>
    <div <?php echo 'class="title ' . esc_attr( $animation ) . '" data-wow-delay="' . esc_attr( $delay ) . 's"'; ?> > <?php echo $text; ?></div>
    <div <?php echo 'class="desc ' . esc_attr( $animation ) . '" data-wow-delay="' . esc_attr( $delay ) . 's"'; ?> > <?php echo $desc; ?></div>
  </div><!-- .contact-item -->

<?php
  return ob_get_clean();
}
add_shortcode( 'contact', 'bw_contact_shortcode' );

function bw_vc_contact_shortcode() {
  $new_animations = bw_get_animations();

  vc_map( array(
    "name"            => __( "Contact", "brainwave" ),
    "base"            => "contact",
    "category"        => __( "Content", "brainwave" ),
    "content_element" => true,
    "params"          => array(
      array(
        "type"        => "textfield",
        "heading"     => __( "Text", "brainwave" ),
        "param_name"  => "text",
        "value"       => "",
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Description", "brainwave" ),
        "param_name"  => "desc",
        "value"       => "",
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Icon Library", "brainwave" ),
        "param_name"  => "icon_lib",
        "value"       => array(
          'Font Awesome' => 'fontawesome',
          'Et Line' => 'etline',
          'Simple Line' => 'simpleline',
          'Elegant' => 'elegant',
        ),
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_elegant',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'elegant',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'elegant',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_etline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'etline',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'etline',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_simpleline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'simpleline',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'simpleline',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_fontawesome',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'fontawesome',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'fontawesome',
        ),
        'value'       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Delay", "brainwave" ),
        "param_name"  => "delay",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Animation", "brainwave" ),
        "param_name"  => "animation",
        "value"       => $new_animations,
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
      array(
        'type'        => 'css_editor',
        'heading'     => __( 'CSS box', 'brainwave' ),
        'param_name'  => 'css',
        'group'       => __( 'Design Options', 'brainwave' )
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_contact_shortcode' );

?>
