<?php

function bw_custom_slide_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
  ), $atts ) );
  ob_start();
?>

  <div class="carousel-item">
    <?php echo apply_filters( 'the_content', $content ); ?>
  </div><!-- .carousel-item -->

<?php
  return ob_get_clean();
}
add_shortcode( 'custom_slide', 'bw_custom_slide_shortcode' );

function bw_vc_custom_slide_shortcode() {
  vc_map( array(
    "name"            => __( "Custom Slide", "brainwave" ),
    "base"            => "custom_slide",
    "category"        => __( "Content", "brainwave" ),
    "content_element" => true,
    "params"          => array(
      array(
        'type'        => 'textarea_html',
        'heading'     => __( 'Content', 'brainwave' ),
        'param_name'  => 'content',
        'value'       => '',
      ),
    ),
  ) );
}
add_action( 'vc_before_init', 'bw_vc_custom_slide_shortcode' );

?>
