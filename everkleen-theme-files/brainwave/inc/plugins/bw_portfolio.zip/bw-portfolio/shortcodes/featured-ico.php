<?php

function bw_features_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'icon_lib'          => '',
    'icon_fontawesome'  => '',
    'icon_elegant'      => '',
    'icon_etline'       => '',
    'icon_simpleline'   => '',
    'animation'         => '',
    'delay'             => '',
    'is_link'           => '',
    'link'              => '',
    'text'              => '',
    'css'               => '',
  ), $atts ) );

  $delay      = ( ! empty( $atts['delay'] ) ) ? $atts['delay'] : '0';
  $animation  = ( ! empty( $atts['animation'] ) ) ? $atts['animation'] . ' wow' : '';
  $text       = ( ! empty( $atts['text'] ) ) ? $atts['text'] : '';
  $is_link    = ( ! empty( $atts['is_link'] ) ) ? true : false;
  $link       = ( ! empty( $atts['link'] ) ) ? $atts['link'] : '#';

  $container = ($is_link) ? 'a href="' . esc_url( $link ) . '"' : 'div';

  switch ( $icon_lib ) {
    case 'etline':
      $icon   = ( ! empty( $atts['icon_etline'] ) ) ? $atts['icon_etline'] : '';
      break;
    case 'elegant':
      $icon   = ( ! empty( $atts['icon_elegant'] ) ) ? $atts['icon_elegant'] : '';
      break;
    case 'simpleline':
      $icon   = ( ! empty( $atts['icon_simpleline'] ) ) ? $atts['icon_simpleline'] : '';
      break;
    default:
      $icon   = ( ! empty( $atts['icon_fontawesome'] ) ) ? $atts['icon_fontawesome'] : '';
      break;
  }
  $css_class  = '';
  ob_start();
  if ( isset( $atts['css'] ) ) :
    $css = $atts['css'];
    $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
?>
    <style type="text/css">
      <?php echo $css; ?>
    </style>
<?php
  endif;

  echo '<' . $container . ' class="features-item ' . esc_attr( $css_class ) . ' ">';
  echo '<div class="align ' . esc_attr( $animation ) . '" data-wow-delay="' . esc_attr( $delay ) . 's">';
  echo '<span class="features-icon"><i class="' . esc_attr( $icon ) . '"></i></span>';
  echo '<div class="title text-uppercase">' . $text . '</div>';
  echo '</div>';
  echo '</' . $container . '>';

  return ob_get_clean();
}
add_shortcode( 'features', 'bw_features_shortcode' );

function bw_features_container_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'text'        => '',
    'after_page'  => '',
  ), $atts ) );
  ob_start();

  echo '<div class="' . esc_attr( $atts['text'] ) . '">';
  echo apply_filters( 'the_content', $content );
  echo '</div>';

  return ob_get_clean();
}
add_shortcode( 'features_container', 'bw_features_container_shortcode' );

function bw_vc_features_shortcode() {

  $new_animations = bw_get_animations();

  vc_map( array(
    "name"                    => __( "Features", "brainwave" ),
    "base"                    => "features_container",
    'show_settings_on_create' => false,
    "category"                => __( "Content", "brainwave" ),
    'content_element'         => true,
    'is_container'            => true,
    "params"                  => array(
      array(
        "type"        => "textfield",
        "heading"     => __( "Wrap Class", "brainwave" ),
        "param_name"  => "text",
        "value"       => __( "full-width features-list ", "brainwave" ),
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
    ),
    'custom_markup'   => '
      <div class="clearfix wpb_holder vc_container_for_children">
      </div>
      <div class="tab_controls">
        <a class="add_feature">' . __( 'Add Feature', 'brainwave' ) . '</a>
      </div>
    ',
    'default_content' => '
      [features]
      [features]
      [features]
      [features]
      [features]
      [features]
    ',
    'js_view'         => 'FeatureView',
  ) );

  vc_map( array(
    "name"            => __( "Feature Icons", "brainwave" ),
    "base"            => "features",
    "class"           => "",
    'content_element' => false,
    "params"          => array(
      array(
        "type"        => "dropdown",
        "heading"     => __( "Icon Library", "brainwave" ),
        "param_name"  => "icon_lib",
        "value"       => array(
          'Font Awesome' => 'fontawesome',
          'Et Line' => 'etline',
          'Simple Line' => 'simpleline',
          'Elegant' => 'elegant',
        ),
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_elegant',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'elegant',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'elegant',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_etline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'etline',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'etline',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_simpleline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'simpleline',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'simpleline',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_fontawesome',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'fontawesome',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'fontawesome',
        ),
        'value'       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Text", "brainwave" ),
        "param_name"  => "text",
        "value"       => "",
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Add link", "brainwave" ),
        "param_name"  => "is_link",
        "value"       => "",
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Link", "brainwave" ),
        "param_name"  => "link",
        'dependency' => array(
            'element' => 'is_link',
            'value' => 'true',
        ),
        "value"       => "#",
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Delay", "brainwave" ),
        "param_name"  => "delay",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Animation", "brainwave" ),
        "param_name"  => "animation",
        "value"       => $new_animations,
      ),
      array(
        'type'        => 'css_editor',
        'heading'     => __( 'CSS box', 'brainwave' ),
        'param_name'  => 'css',
        'group'       => __( 'Design Options', 'brainwave' )
      ),
    ),
  ) );
}
add_action( 'vc_before_init', 'bw_vc_features_shortcode' );

?>
