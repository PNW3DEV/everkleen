<?php

function bw_icon_block_shortcode( $atts, $content = null ) {
  extract( shortcode_atts( array(
    'title'             => '',
    'desc'              => '',
    'icon_lib'          => '',
    'icon_fontawesome'  => '',
    'icon_elegant'      => '',
    'icon_etline'       => '',
    'icon_simpleline'   => '',
    'animation'         => '',
    'delay'             => '',
  ), $atts ) );

  $title     = ( ! empty( $atts['title'] ) ) ? $atts['title'] : '';
  $desc      = ( ! empty( $atts['desc'] ) ) ? $atts['desc'] : '';

  $delay      = ( ! empty( $atts['delay'] ) ) ? $atts['delay'] : '0';
  $animation  = ( ! empty( $atts['animation'] ) ) ? $atts['animation'] . ' wow' : '';

  switch ( $icon_lib ) {
    case 'etline':
      $icon   = ( ! empty( $atts['icon_etline'] ) ) ? $atts['icon_etline'] : '';
      break;
    case 'elegant':
      $icon   = ( ! empty( $atts['icon_elegant'] ) ) ? $atts['icon_elegant'] : '';
      break;
    case 'simpleline':
      $icon   = ( ! empty( $atts['icon_simpleline'] ) ) ? $atts['icon_simpleline'] : '';
      break;
    default:
      $icon   = ( ! empty( $atts['icon_fontawesome'] ) ) ? $atts['icon_fontawesome'] : '';
      break;
  }
  ob_start();
  ?>
  <div class="feature-box <?php echo esc_attr( $animation ); ?>" data-wow-delay="<?php echo esc_attr( $delay ); ?>s">
    <div class="feature-box-icon"> <i class="<?php echo esc_attr( $icon ); ?>"></i> </div>
    <div class="feature-box-info">
      <div class="title"><?php echo esc_html( $title ); ?></div>
      <p class="tall"><?php echo esc_html( $desc ); ?></p>
    </div>
  </div>
  <?php
  return ob_get_clean();
}
add_shortcode( 'icon_block', 'bw_icon_block_shortcode' );

function bw_vc_icon_block_shortcode() {
  $new_animations = bw_get_animations();

  vc_map( array(
    "name"            => __( "Icon Block", "brainwave" ),
    "base"            => "icon_block",
    "category"        => __( "Content", "brainwave" ),
    "content_element" => true,
    "params"          => array(
      array(
        "type"        => "textfield",
        "heading"     => __( "Title", "brainwave" ),
        "param_name"  => "title",
        "value"       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Description", "brainwave" ),
        "param_name"  => "desc",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Icon Library", "brainwave" ),
        "param_name"  => "icon_lib",
        "value"       => array(
          'Font Awesome'  => 'fontawesome',
          'Et Line'       => 'etline',
          'Simple Line'   => 'simpleline',
          'Elegant'       => 'elegant',
        ),
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_elegant',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'elegant',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'elegant',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_etline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'etline',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'etline',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_simpleline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'simpleline',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'simpleline',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_fontawesome',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'fontawesome',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'fontawesome',
        ),
        'value'       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Delay", "brainwave" ),
        "param_name"  => "delay",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Animation", "brainwave" ),
        "param_name"  => "animation",
        "value"       => $new_animations,
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_icon_block_shortcode' );

?>
