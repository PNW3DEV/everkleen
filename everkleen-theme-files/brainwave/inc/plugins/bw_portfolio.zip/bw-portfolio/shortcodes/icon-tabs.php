<?php

function bw_icon_tabs( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'tab_id'            => '',
    'icon_lib'          => 'fontawesome',
    'icon_fontawesome'  => '',
    'icon_elegant'      => '',
    'icon_etline'       => '',
    'icon_simpleline'   => '',
  ), $atts ) );
  $tab_id = ( ! empty( $atts['tab_id'] ) ) ? $atts['tab_id'] : '';
  $tab_id = str_replace(' ', '_', strtolower( $tab_id ) );

  $is_active = ( ! empty( $atts['is_active'] ) ) ? true : false;
  $tab_content = ( ! empty( $atts['tab_content'] ) ) ? $atts['tab_content'] : '';
  switch ( $icon_lib ) {
    case 'etline':
      $icon   = ( ! empty( $atts['icon_etline'] ) ) ? $atts['icon_etline'] : '';
      break;
    case 'elegant':
      $icon   = ( ! empty( $atts['icon_elegant'] ) ) ? $atts['icon_elegant'] : '';
      break;
    case 'simpleline':
      $icon   = ( ! empty( $atts['icon_simpleline'] ) ) ? $atts['icon_simpleline'] : '';
      break;
    default:
      $icon   = ( ! empty( $atts['icon_fontawesome'] ) ) ? $atts['icon_fontawesome'] : '';
      break;
  }
  ob_start();
  ?>
      <div role="tabpanel" class="tab-pane fade  <?php echo ( $is_active == true ) ? 'in active' : ''; ?>" id="<?php echo esc_attr( $tab_id ); ?>">
        <div class="col-sm-8 col-sm-offset-2 text-center">
          <?php echo apply_filters( 'the_content', $content ); ?>
        </div>
      </div>
<?php
  return ob_get_clean();
}
add_shortcode( 'icon-tabs', 'bw_icon_tabs' );

function bw_icon_tabs_container_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'after_page' => '',
  ), $atts ) );

  $temp = $content;

  if ( has_shortcode( $content, 'icon-tabs' ) ) {
  $content = str_replace( '[', "\n<", $content);
  $content = str_replace( ']', ">\n",  $content );
  $content = "<?xml version='1.0' standalone='yes'?><container>" . trim( $content ) . "</container>";

  $xml = new SimpleXMLElement( $content );
  $count = 0;

  ob_start();
  ?>
  <div class="work-process mt65">
    <ul class="nav nav-tabs" role="tablist">
    <?php
      foreach ( $xml->{'icon-tabs'} as $value) :
        $count++;
        $lib = 'icon_' . $value['icon_lib'];
        $tab_id = str_replace(' ', '_', strtolower( $value['tab_id'] ) );
        ?>
        <li role="presentation" <?php echo ( $value['is_active'] == true ) ? 'class="active"' : ''; ?>><a href="#<?php echo esc_attr( $tab_id ); ?>" aria-controls="<?php echo esc_attr( $tab_id ); ?>" role="tab" data-toggle="tab"><span><span><?php echo '0' . $count; ?></span><i class="<?php echo esc_attr( $value[ $lib ] ); ?>"></i></span><?php echo esc_html( $value['tab_id'] ); ?></a></li>
    <?php endforeach; ?>

    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <?php echo apply_filters( 'the_content', $temp ); ?>
    </div>
    <div class="clearfix"></div>
  </div>
  <?php
  }

  return ob_get_clean();
}
add_shortcode( 'icon_tabs_container', 'bw_icon_tabs_container_shortcode' );


function bw_vc_icon_tabs() {
  vc_map( array(
    "name"            => __( "Icon Tabs Container", "brainwave" ),
    "base"            => "icon_tabs_container",
    "category"        => __( "Content", "brainwave" ),
    'content_element' => true,
    'is_container'    => true,
    'custom_markup'   => '
      <div class="clearfix wpb_holder vc_container_for_children">
      </div>
      <div class="tab_controls">
        <a class="add_icon_tab">' . __( 'Add Tab', 'brainwave' ) . '</a>
      </div>
    ',
    'default_content' => '
      [icon-tabs]
      [icon-tabs]
      [icon-tabs]
      [icon-tabs]
    ',
    "params"          => array(
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
    ),
    'js_view'         => 'IconTabsView',
  ) );

  vc_map( array(
    "name"            => __( "Icon Tabs", "brainwave" ),
    "base"            => "icon-tabs",
    "category"        => __( "Content", "brainwave" ),
    'content_element' => false,
    "params"          => array(
      array(
        "type"        => "textfield",
        "heading"     =>  __( 'Tab ID', 'brainwave' ),
        "param_name"  => "tab_id",
        "value"       => '',
      ),
      array(
        "type"        => "checkbox",
        "heading"     =>  __( 'Active', 'brainwave' ),
        "param_name"  => "is_active",
        "description" => __( 'Don\'t use for more than one tab for normal functionality', 'brainwave' ),
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Icon Library", "brainwave" ),
        "param_name"  => "icon_lib",
        "value"       => array(
          '---' => '',
          'Font Awesome' => 'fontawesome',
          'Et Line' => 'etline',
          'Simple Line' => 'simpleline',
          'Elegant' => 'elegant',
        ),
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_elegant',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'elegant',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'elegant',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_etline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'etline',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'etline',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_simpleline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'simpleline',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'simpleline',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_fontawesome',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'fontawesome',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'fontawesome',
        ),
        'value'       => '',
      ),
      array(
        "type"        => "textarea_html",
        "heading"     =>  __( 'Content', 'brainwave' ),
        "param_name"  => "content",
        "value"       => '',
      ),

    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_icon_tabs' );

?>
