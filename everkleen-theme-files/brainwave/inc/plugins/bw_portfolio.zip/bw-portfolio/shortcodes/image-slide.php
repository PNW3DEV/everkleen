<?php

function bw_image_slide_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'img' => '',
  ), $atts ) );
  $css_class  = '';
  $img        = $atts['img'];
  ob_start();

  echo '<div class="' . esc_attr( $css_class ) . '">';
  echo '<img src="' . esc_url( wp_get_attachment_url( $img ) ) . '" alt="">';
  echo '</div>';

  return ob_get_clean();
}
add_shortcode( 'img_slide', 'bw_image_slide_shortcode' );

function bw_vc_image_slide_shortcode() {
  vc_map( array(
    "name"            => __( "Image Slide", "brainwave" ),
    "base"            => "img_slide",
    "category"        => __( "Content", "brainwave" ),
    "content_element" => true,
    "params"          => array(
      array(
        'type'        => 'attach_image',
        'heading'     => __( 'Image', 'brainwave' ),
        'param_name'  => 'img',
        'value'       => '',
      ),
      array(
        'type'        => 'css_editor',
        'heading'     => __( 'CSS box', 'brainwave' ),
        'param_name'  => 'css',
        'group'       => __( 'Design Options', 'brainwave' )
      ),
    ),
  ) );
}
add_action( 'vc_before_init', 'bw_vc_image_slide_shortcode' );

?>
