<?php

function bw_indents_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'mt'    => '',
    'mt_lg' => '',
    'mt_md' => '',
    'mt_sm' => '',
    'mt_xs' => '',
  ), $atts ) );
  ob_clean();
  ob_start();
  echo '<div class="col-sm-12 ';
  foreach ( $atts as $key => $value ) {
    echo esc_attr( str_replace( '_', '-', $key ) . '' . esc_attr( $value ) . ' ' );
  }
  echo '"></div>';
  return ob_get_clean();
}
add_shortcode( 'indents', 'bw_indents_shortcode' );

function bw_vc_indents_shortcode() {
  vc_map( array(
    "name"            => __( "Indents", "brainwave" ),
    "base"            => "indents",
    "category"        => __( "Content", "brainwave" ),
    'content_element' => true,
    "params"          => array(
      // Desktop
      array(
        "type"        => "textfield",
        "heading"     =>  __( 'Indent General', 'brainwave' ),
        "description"     =>  __( 'Value from -100 to 100', 'brainwave' ),
        "param_name"  => "mt",
        "value"       => '',
      ),

      // Large Desktops
      array(
        "type"        => "textfield",
        "heading"     =>  __( 'Indent Large Desktop', 'brainwave' ),
        "description"     =>  __( 'Value from -100 to 100', 'brainwave' ),
        "param_name"  => "mt_lg",
        "value"       => '',
      ),
      // Desktops
      array(
        "type"        => "textfield",
        "heading"     =>  __( 'Indent Desktop', 'brainwave' ),
        "description"     =>  __( 'Value from -100 to 100', 'brainwave' ),
        "param_name"  => "mt_md",
        "value"       => '',
      ),
      // Tablet
      array(
        "type"        => "textfield",
        "heading"     =>  __( 'Indent Tablet', 'brainwave' ),
        "description"     =>  __( 'Value from -100 to 100', 'brainwave' ),
        "param_name"  => "mt_sm",
        "value"       => '',
      ),
      // Phones
      array(
        "type"        => "textfield",
        "heading"     =>  __( 'Indent Phones', 'brainwave' ),
        "description"     =>  __( 'Value from -100 to 100', 'brainwave' ),
        "param_name"  => "mt_xs",
        "value"       => '',
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_indents_shortcode' );

?>
