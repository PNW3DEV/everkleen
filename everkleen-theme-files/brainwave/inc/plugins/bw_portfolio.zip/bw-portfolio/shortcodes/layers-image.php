<?php

function bw_layers_image_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'animation'   => '',
    'delay'       => '',
    'img'         => '',
    'layer'       => '',
  ), $atts ) );
  $delay      = ( isset( $atts['delay'] ) ) ? $atts['delay'] : '0';
  $animation  = ( isset( $atts['animation'] ) ) ? $atts['animation'] . ' wow' : '';
  $image      = ( isset( $atts['img'] ) ) ? $atts['img'] : '';
  $layer      = ( isset( $atts['layer'] ) ) ? $atts['layer'] : '';

  ob_start();
  echo '<img class="' . esc_attr( $layer ) . ' ' . esc_attr( $animation ) . '" alt="" data-wow-delay="' . esc_attr( $delay ) . 's" src="' . esc_url( wp_get_attachment_url( $image ) ) . '">';
  return ob_get_clean();
}
add_shortcode( 'layers-img', 'bw_layers_image_shortcode' );

function bw_layers_image_container_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'after_page'  => '',
  ), $atts ) );
  ob_start();

  echo '<div class="layers">';
  $new_layers = array();
  while ( ! empty( $content ) ) {
    array_push( $new_layers, substr( $content, strpos( $content, '[' ), strpos( $content, ']' ) ) );
    $content = substr( $content, strpos( $content, ']' ) + 1 );
  }
  foreach ( $new_layers as $key => $value ) {
    if ( $key + 1 != count( $new_layers ) ) {
      $value .= ' layer="layer"]';
    } else {
      $value .= ']';
    }
    echo do_shortcode( $value );
  }
  echo '</div>';

  return ob_get_clean();
}
add_shortcode( 'layers_container', 'bw_layers_image_container_shortcode' );

function bw_vc_layers_image_shortcode() {
  $new_animations = bw_get_animations();

  vc_map( array(
    "name"                    => __( "Layers", "brainwave" ),
    "base"                    => "layers_container",
    'show_settings_on_create' => false,
    "category"                => __( "Content", "brainwave" ),
    'content_element'         => true,
    'is_container'            => true,
    "params"                  => array(
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
    ),
    'custom_markup'   => '
      <div class="clearfix wpb_holder vc_container_for_children">
      </div>
      <div class="tab_controls">
        <a class="add_layer">' . __( 'Add Layer', 'brainwave' ) . '</a>
      </div>
    ',
    'default_content' => '
      [layers-img]
      [layers-img]
      [layers-img]
    ',
    'js_view'         => 'LayersView',
  ) );


  vc_map( array(
    "name"      => __( "Image Layers", "brainwave" ),
    "base"      => "layers-img",
    "category"  => __( "Content", "brainwave"),
    "params"    => array(
      array(
        "type"        => "attach_image",
        "heading"     => __( "Images", "brainwave" ),
        "param_name"  => "img",
        "value"       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Delay", "brainwave" ),
        "param_name"  => "delay",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Animation", "brainwave" ),
        "param_name"  => "animation",
        "value"       => $new_animations,
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_layers_image_shortcode' );

?>
