<?php

function bw_map_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'type'        => '',
    'lon'         => '',
    'lat'         => '',
    'title'       => '',
    'after_page'  => '',
    'css'         => '',
  ), $atts ) );
  $type  = ( ! empty( $atts['type'] ) ) ? $atts['type'] : 'horizontal';
  $lon   = ( ! empty( $atts['lon'] ) ) ? $atts['lon'] : '';
  $lat   = ( ! empty( $atts['lat'] ) ) ? $atts['lat'] : 'horizontal';
  $title = ( ! empty( $atts['title'] ) ) ? $atts['title'] : 'horizontal';

  $css_class  = '';
  ob_start();
  if ( isset( $atts['css'] ) ) :
    $css        = $atts['css'];
    $css_class  = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
?>
    <style type="text/css">
      <?php echo $css; ?>
    </style>
  <?php endif; ?>

  <?php $classes = ( $type == 'vertical' ) ? 'col-sm-6 col-sm-offset-6' : ''; ?>
  <div class="page-section map-section <?php echo ( $type == 'vertical' ) ? ' style-2 ' : ''; echo ( ! empty( $css ) ) ? esc_attr( $css_class ) : ''; ?>">
    <div class="map-block <?php echo $classes; ?>">
      <?php if ( $type == 'horizontal' ) : ?>
        <a href="#" class="text-uppercase text-center open-map"><?php _e( 'Open the map', 'brainwave' ); ?> <i class="fa fa-angle-down"></i></a>
        <a href="#" class="text-uppercase text-center close-map"><?php _e( 'Close the map', 'brainwave' ); ?> <i class="fa fa-angle-up"></i></a>
      <?php endif; ?>
      <div id="map-canvas" data-map-lon="<?php echo esc_attr( $lon ); ?>" data-map-lat="<?php echo esc_attr( $lat ); ?>" data-map-marker-lon="<?php echo esc_attr( $lon ); ?>" data-map-marker-lat="<?php echo esc_attr( $lat ); ?>" data-map-marker-title="<?php echo esc_attr( $title ); ?>"></div>
    </div>
    <?php if ( $type == 'horizontal' ) : ?>
      <div class="map-content"></div>
    <?php endif; ?>
    <div class="container">
      <?php if ( $type == 'vertical' ) : ?>
        <div class="col-sm-6">
      <?php endif; ?>
      <?php echo apply_filters( 'the_content', $content ); ?>
      <?php if ( $type == 'vertical' ) : ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

<?php
  return ob_get_clean();
}
add_shortcode( 'bw_map', 'bw_map_shortcode' );

function bw_vc_map_shortcode() {
  vc_map( array(
    "name"            => __( "Map", "brainwave" ),
    "base"            => "bw_map",
    "category"        => __( "Content", "brainwave" ),
    "content_element" => true,
    "params"          => array(
      array(
        "type"        => "dropdown",
        "heading"     => __( "Type", "brainwave" ),
        "param_name"  => "type",
        "value"       => array(
          'Horizontal'      => 'horizontal',
          'Vertical'        => 'vertical',
        ),
      ),
      array(
        'type'        => 'textarea_html',
        'heading'     => __( 'Shortcode', 'brainwave' ),
        'param_name' => 'content',
        'value' => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Lon", "brainwave" ),
        "param_name"  => "lon",
        "value"       => "",
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Lat", "brainwave" ),
        "param_name"  => "lat",
        "value"       => "",
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Marker Title", "brainwave" ),
        "param_name"  => "title",
        "value"       => "",
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
      array(
        'type'        => 'css_editor',
        'heading'     => __( 'CSS box', 'brainwave' ),
        'param_name'  => 'css',
        'group'       => __( 'Design Options', 'brainwave' )
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_map_shortcode' );

?>
