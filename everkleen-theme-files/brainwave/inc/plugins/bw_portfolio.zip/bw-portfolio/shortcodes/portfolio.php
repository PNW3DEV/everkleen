<?php

function bw_portfolio_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  global $brainwave;
  extract( shortcode_atts( array(
    'cats'        => '',
    'columns'     => '',
    'sort'        => '',
    'order'       => '',
    'count'       => '',
    'after_page'  => '',
    'css'         => '',
  ), $atts ) );

  $cats       = ( ! empty( $atts['cats'] ) ) ? $atts['cats'] : 'all';
  $columns    = ( ! empty( $atts['columns'] ) ) ? $atts['columns'] : 'two';
  $sort       = ( ! empty( $atts['sort'] ) ) ? $atts['sort'] . ',' : 'date,';
  $order      = ( ! empty( $atts['order'] ) ) ? $atts['order'] : 'asc';
  $count      = ( ! empty( $atts['count'] ) ) ? $atts['count'] : get_option('posts_per_page');
  $css_class  = '';
  $temp       = 0;

  $open_class = 'single-page-load';
  if ( ! empty( $brainwave['portfolio_popup'] ) ) {
    if ( $brainwave['portfolio_popup'] ) {
      $open_class = 'ajax-popup-link';
    }
  }
  ob_start();

  if ( isset( $atts['css'] ) ) :
    $css        = $atts['css'];
    $css_class  = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
?>
    <style type="text/css">
      <?php echo $css; ?>
    </style>
<?php endif; ?>
    <div class="portfolio  <?php echo ( ! empty( $css ) ) ? esc_attr( $css_class ) : ''; ?>">
    <?php if ( ( $columns != 'paralax' ) && ( $cats == 'all') ) : ?>
        <!-- Filters -->
        <div class="portfolio-filter text-center">
          <button class="btn btn-default btn-xs active" data-filter="*"><?php _e( 'All', 'brainwave' ); ?></button>
          <?php
            $categories = bw_get_portfolio_categories();
            foreach ( $categories as $category ) {
              $category = (array) $category;
              echo '<button class="btn btn-default btn-xs" data-filter=".' . esc_attr( strtolower( str_replace( ' ', '-', trim( $category['name'] ) ) )  ) . '">' . $category['name'] . '</button>';
            }
          ?>
        </div>
        <!-- .portfolio-filter -->
<?php endif; ?>
        <!-- List -->
        <?php
          switch ( $columns ) {
            case 'two':
              $view_variant = 'two-column';
              break;
            case 'three':
              $view_variant = 'three-column';
              break;
            case 'four':
              $view_variant = 'four-column';
              break;
            case 'paralax':
              $view_variant = 'paralax';
              break;
            case 'masonry':
              $view_variant = 'masonry';
              break;
            default:
              break;
          }
        ?>
        <ul class="portfolio-list <?php echo esc_attr( $view_variant ); ?> list-unstyled">
          <?php
            if ( $columns != 'paralax' ) : echo '<li class="grid-sizer"></li>'; endif;

            $query_args = array(
              'post_type'       => 'portfolio',
              'orderby'         => $sort,
              'order'           => $order,
              'post_count'      => $count,
              'posts_per_page'  => $count,
            );

            if ( $cats !== 'all' ) {
              $query_args['meta_query'] = array(
  	              'book_color' => array(
              		'key'     => 'block_categories',
              		'value'   => $cats,
              		'compare' => 'LIKE',
              	),
              );
            }

            $query = new WP_Query( $query_args );

            if ( $query->have_posts() ) {
              while ( $query->have_posts() ) {
                $query->the_post();
                $outcat = '';
                $outcat_classes = '';
                $post_cat = bw_get_portfolio_post_categories( get_post( get_the_ID() ) );
                global $wpdb;
                $temp = 0;
                for ( $i=0; $i < strlen( $post_cat ); $i++ ) {
                  if ( $post_cat[ $i ] === ',' ) {
                    $cat = trim(substr( $post_cat, $temp, $i - $temp ));
                    $temp = $i+1;
                    $result = $wpdb->get_results( "SELECT name FROM " . $wpdb->prefix . "bw_block_categories WHERE id = '" . $cat . "'" );
                    if ( $result ) {
                      $cat = (array) $result[0];
                      if ( ! empty( $outcat ) ) {
                        $outcat .= ', ' . $cat['name'];
                        $outcat_classes .= ' ' . strtolower( str_replace(' ', '-', trim( $cat['name'] ) ) );
                      } else {
                        $outcat .= $cat['name'];
                        $outcat_classes .= strtolower( str_replace(' ', '-', trim( $cat['name'] ) ) );
                      }
                    } else {
                      $outcat = '';
                    }
                  }
                }

                switch ( $columns ) {
                  case 'two':
                    echo '<li class="portfolio-item ' . esc_attr( $outcat_classes ) . ' work-ajax-link">';
                    echo '<a href="' . esc_url( get_permalink() ) . '" class="' . esc_attr( $open_class ) . '" data-title="' . esc_attr( get_bloginfo('name') . ' | ' . get_the_title() ) . '">';
                    if ( has_post_thumbnail( get_the_ID() ) ) {
                      echo get_the_post_thumbnail( get_the_ID() );
                    }
                    echo '<div class="info-container">';
                    echo '<div class="title">' . get_the_title() . '</div>';
                    echo '<div class="category">' . esc_html( $outcat ) . '</div>';
                    echo '</div>';
                    echo '</a>';
                    echo '</li>';
                    $outcat = '';
                    $outcat_classes = '';
                    break;
                  case 'three':
                    echo '<li class="portfolio-item ' . esc_attr( $outcat_classes ) . ' work-ajax-link">';
                    echo '<a href="' . esc_url( get_permalink() ) . '" class="' . esc_attr( $open_class ) . '" data-title="' . esc_attr( get_bloginfo('name') . ' | ' . get_the_title() ) . '">';
                    if ( has_post_thumbnail( get_the_ID() ) ) {
                      echo get_the_post_thumbnail( get_the_ID() );
                    }
                    echo '<div class="info-container">';
                    echo '<div class="title">' . get_the_title() . '</div>';
                    echo '<div class="category">' . esc_html( $outcat ) . '</div>';
                    echo '</div>';
                    echo '</a>';
                    echo '</li>';
                    $outcat = '';
                    $outcat_classes = '';
                    break;
                  case 'four':
                    echo '<li class="portfolio-item ' . esc_attr( $outcat_classes ) . ' work-ajax-link">';
                    echo '<a href="' . esc_url( get_permalink() ) . '" class="' . esc_attr( $open_class ) . '" data-post-id="' . esc_attr( get_the_ID() ) . '" data-title="' . esc_attr( get_bloginfo('name') . ' | ' . get_the_title() ) . '">';
                    if ( has_post_thumbnail( get_the_ID() ) ) {
                      echo get_the_post_thumbnail( get_the_ID() );
                    }
                    echo '<div class="info-container">';
                    echo '<div class="title">' . get_the_title() . '</div>';
                    echo '<div class="category">' . esc_html( $outcat ) . '</div>';
                    echo '</div>';
                    echo '</a>';
                    echo '</li>';
                    $outcat = '';
                    $outcat_classes = '';
                    break;
                  case 'paralax':
                    echo '<li class="portfolio-item ' . esc_attr( $outcat_classes ) . ' work-ajax-link" data-background="' . esc_attr( wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) ) ) . '" >';
                    echo '<div class="info-wrapper text-center">';
                    echo '<div class="title">' . get_the_title() . '</div>';
                    echo '<a href="' . esc_url( get_permalink() ) . '" class="btn btn-default btn-inverted ' . esc_attr( $open_class ) . '" data-title="' . esc_attr( get_bloginfo('name') . ' | ' . get_the_title() ) . '">' . __( 'See Project', 'brainwave' ) . '</a>';
                    echo '</div>';
                    echo '</li>';
                    $outcat = '';
                    $outcat_classes = '';
                    break;
                  case 'masonry':
                    $size = get_post_meta( get_the_ID(), 'masonry_view', true );
                    if ( $size == '2x2' ) : $size = 'large'; endif;
                    echo '<li class="portfolio-item ' . esc_attr( $size ) . ' ' . esc_attr( $outcat_classes ) . ' work-ajax-link">';
                    echo '<a href="' . esc_url( get_permalink() ) . '" class="' . esc_attr( $open_class ) . '" data-title="' . esc_attr( get_bloginfo('name') . ' | ' . get_the_title() ) . '">';
                    if ( has_post_thumbnail( get_the_ID() ) ) {
                      echo get_the_post_thumbnail( get_the_ID() );
                    }
                    echo '<div class="info-container">';
                    echo '<div class="title">' . get_the_title() . '</div>';
                    echo '<div class="category">' . esc_html( $outcat ) . '</div>';
                    echo '</div>';
                    echo '</a>';
                    echo '</li>';
                    $outcat = '';
                    $outcat_classes = '';
                    break;
                  default:
                    break;
                }
              }
            }
          ?>
        </ul>
        <!-- .portfolio-list -->
        <div class="clearfix"></div>
    </div>
<?php
  return ob_get_clean();
}
add_shortcode( 'portfolio', 'bw_portfolio_shortcode' );

function bw_vc_portfolio_shortcode() {

    $categories = bw_get_portfolio_categories();
    $new_cats = array(
      'All'=>'all)'
    );
    foreach ( $categories as $category ) {
      $category = (array) $category;
      $new_cats[ $category["name"] ] = $category["id"];
    }
    // var_dump($new_cats);

  vc_map( array(
    "name"            => __( "Portfolio", "brainwave" ),
    "base"            => "portfolio",
    "category"        => __( "Content", "brainwave" ),
    'content_element' => true,
    "params"          => array(
      array(
        "type"        => "dropdown",
        "heading"     =>  __( 'Category to display', 'brainwave' ),
        "param_name"  => "cats",
        "value"       => $new_cats,
      ),
      array(
        "type"        => "dropdown",
        "heading"     =>  __( 'Columns', 'brainwave' ),
        "param_name"  => "columns",
        "value"       => array(
          'Two'         => 'two',
          'Three'       => 'three',
          'Four'        => 'four',
          'Parralax'    => 'paralax',
          'Masonry'     => 'masonry',
        ),
      ),
      array(
        "type"        => "dropdown",
        "heading"     =>  __( 'Sort By', 'brainwave' ),
        "param_name"  => "sort",
        "value"       => array(
          'Date'  => 'date',
          'Title' => 'title',
        ),
      ),
      array(
        "type"        => "dropdown",
        "heading"     =>  __( 'Order By', 'brainwave' ),
        "param_name"  => "order",
        "value"       => array(
          'ASC'   => 'asc',
          'DESC'  => 'desc',
        ),
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( 'Number of Posts', 'brainwave' ),
        "param_name"  => "count",
        "value"       => '',
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
      array(
        'type'        => 'css_editor',
        'heading'     => __( 'CSS box', 'brainwave' ),
        'param_name'  => 'css',
        'group'       => __( 'Design Options', 'brainwave' )
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_portfolio_shortcode' );

?>
