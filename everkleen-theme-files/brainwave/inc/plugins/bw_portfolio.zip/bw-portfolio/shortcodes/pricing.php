<?php

function bw_pricing_container_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'title'        		  => '',
    'icon_lib'  		    => '',
    'icon_fontawesome'  => '',
    'icon_elegant'      => '',
    'icon_etline'       => '',
    'icon_simpleline'   => '',
    'price'        		  => '',
    'per'        		    => '',
    'style'        		  => '',
    'url'        		    => '',
    'animation'         => '',
    'delay'             => '',
    'btn_text'             => '',
    'after_page'  		  => '',
  ), $atts ) );

  $title 	    = ( ! empty( $atts['title'] ) ) ? $atts['title'] : '';
  $delay      = ( ! empty( $atts['delay'] ) ) ? $atts['delay'] : '0';
  $animation  = ( ! empty( $atts['animation'] ) ) ? $atts['animation'] . ' wow' : '';
  $price 	    = ( ! empty( $atts['price'] ) ) ? $atts['price'] : '';
  $per 		    = ( ! empty( $atts['per'] ) ) ? $atts['per'] : '';
  $style 	    = ( ! empty( $atts['style'] ) ) ? $atts['style'] : 'dark';
  $url 		    = ( ! empty( $atts['url'] ) ) ? $atts['url'] : '#';
  $btn_text   = ( ! empty( $atts['btn_text'] ) ) ? $atts['btn_text'] : 'Sign up now';

  switch ( $icon_lib ) {
  	case 'etline':
  		$icon 	= ( ! empty( $atts['icon_etline'] ) ) ? $atts['icon_etline'] : '';
  		break;
  	case 'elegant':
  		$icon 	= ( ! empty( $atts['icon_elegant'] ) ) ? $atts['icon_elegant'] : '';
  		break;
  	case 'simpleline':
  		$icon 	= ( ! empty( $atts['icon_simpleline'] ) ) ? $atts['icon_simpleline'] : '';
  		break;
  	default:
  		$icon 	= ( ! empty( $atts['icon_fontawesome'] ) ) ? $atts['icon_fontawesome'] : '';
  		break;
  }

  ob_start();


  	if ( $style == 'icon' ) {
  		echo '<a class="pricing-item style-3 ' . esc_attr( $animation ) . '" data-wow-delay="' . esc_attr( $delay ) . 's" href="' . esc_url( $url ) . '">';

  		echo '<div class="title text-center">';
  		echo '<div class="fs1 icon ' . esc_attr( $icon ) .'" aria-hidden="true"></div>';
  		echo '<span class="title">' . $title . '</span>';
  		echo '</div>';

  		echo '<div class="text-center">';

  		echo '<ul class="list-unstyled">';
  		echo apply_filters( 'the_content', $content );
  		echo '</ul>';

  		echo '<div class="price-box">';
  		echo '<div class="price">' . $price . '</div>';
  		echo '<div class="per">' . $per . '</div>';
  		echo '</div>';
  		echo '</div>';
  		echo '</a>';
  	} else {
  		$btn = 'btn btn-primary';
  		if ( $style == 'dark' ) : $btn .= ' btn-inverted'; endif;
  		if ( $style != 'transparent' ) : $style .= ' style-1'; endif;
  		echo '<div class="pricing-item ' . esc_attr( $style ) . ' ' . esc_attr( $animation ) . '" data-wow-delay="' . esc_attr( $delay ) . 's">';
  		echo '<div class="text-center">';
  		echo '<div class="price-box">';
  		echo '<div class="price">' . $price . '</div>';
  		echo '<div class="per">' . $per . '</div>';
  		echo '</div>';
  		echo '</div>';

  		echo '<div class="title">';
  		echo '<span>' . $title . '</span>';
  		echo '</div>';

  		echo '<div class="text-center">';
  		echo '<ul class="list-unstyled">';
  		echo apply_filters( 'the_content', $content );
  		echo '</ul>';

  		echo '<a href="' . esc_url( $url ) . '" class="' . esc_attr( $btn ) . '">' . esc_html( $btn_text ) . '</a>';
  		echo '</div>';
  		echo '</div>';
  	}

  return ob_get_clean();
}
add_shortcode( 'pricing_container', 'bw_pricing_container_shortcode' );

function bw_pricing_shortcode( $atts, $content = null ) { // New function parameter $content is added!
	extract( shortcode_atts( array(
	  'text'        => '',
	  'strike'      => '',
    'animation'   => '',
    'delay'       => '',
	), $atts ) );

	$text       = ( ! empty( $atts['text'] ) ) ? $atts['text'] : '';
	$strike     = ( ! empty( $atts['strike'] ) ) ? ' class="through"' : '';
  $delay      = ( ! empty( $atts['delay'] ) ) ? $atts['delay'] : '';
  $animation  = ( ! empty( $atts['animation'] ) ) ? $atts['animation'] : '';

	ob_start();
	echo '<li' . $strike . '>' . $text . '</li>';
	return ob_get_clean();
}
add_shortcode( 'pricing', 'bw_pricing_shortcode' );

function bw_vc_pricing_shortcode() {
  $new_animations = bw_get_animations();

  vc_map( array(
    "name"                    => __( "Pricing", "brainwave" ),
    "base"                    => "pricing_container",
    "category"                => __( "Content", "brainwave" ),
    'content_element'         => true,
    'is_container'            => true,
    "params"                  => array(
      array(
        "type"        => "textfield",
        "heading"     => __( "Title", "brainwave" ),
        "param_name"  => "title",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Icon Library", "brainwave" ),
        "param_name"  => "icon_lib",
        "value"       => array(
        	'Font Awesome' => 'fontawesome',
        	'Et Line' => 'etline',
        	'Simple Line' => 'simpleline',
        	'Elegant' => 'elegant',
        ),
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_elegant',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'		  => 'elegant',
        ),
    		'dependency' => array(
		    'element' => 'icon_lib',
		    'value' => 'elegant',
		),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_etline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'		  => 'etline',
        ),
    		'dependency' => array(
		    'element' => 'icon_lib',
		    'value' => 'etline',
		),
	    'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_simpleline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'		  => 'simpleline',
        ),
    		'dependency' => array(
		    'element' => 'icon_lib',
		    'value' => 'simpleline',
		),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_fontawesome',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'		  => 'fontawesome',
        ),
    		'dependency' => array(
		    'element' => 'icon_lib',
		    'value' => 'fontawesome',
		),
        'value'       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Price", "brainwave" ),
        "param_name"  => "price",
        "value"       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Period", "brainwave" ),
        "param_name"  => "per",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Style", "brainwave" ),
        "param_name"  => "style",
        "value"       => array(
        	'Dark' 			=> 'dark',
        	'White' 		=> 'white',
        	'Transparent' 	=> 'transparent',
        	'With Icon' 	=> 'icon',
        ),
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Url", "brainwave" ),
        "param_name"  => "url",
        "value"       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Delay", "brainwave" ),
        "param_name"  => "delay",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Animation", "brainwave" ),
        "param_name"  => "animation",
        "value"       => $new_animations,
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Button text", "brainwave" ),
        "param_name"  => "btn_text",
        "value"       => __( 'Sign up now', 'brainwave' ),
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
    ),
    'custom_markup'   => '
      <div class="clearfix wpb_holder vc_container_for_children">
      </div>
      <div class="tab_controls">
        <a class="add_pricing">' . __( 'Add Price', 'brainwave' ) . '</a>
      </div>
    ',
    'default_content' => '
      [pricing]
      [pricing]
      [pricing]
      [pricing]
      [pricing]
      [pricing]
      [pricing]
    ',
    'js_view'         => 'PricingView',
  ) );

  vc_map( array(
    "name"      => __( "Pricing Text", "brainwave" ),
    "base"      => "pricing",
    'content_element' => false,
    "params"    => array(
      array(
        "type"        => "textfield",
        "heading"     => __( "Text", "brainwave" ),
        "param_name"  => "text",
        "value"       => '',
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Striketrough", "brainwave" ),
        "param_name"  => "strike",
        "value"       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Delay", "brainwave" ),
        "param_name"  => "delay",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Animation", "brainwave" ),
        "param_name"  => "animation",
        "value"       => $new_animations,
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_pricing_shortcode' );
