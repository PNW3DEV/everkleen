<?php

function bw_project_details_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'project_client'  => '',
    'project_date'    => '',
    'project_link'    => '',
    'after_page'      => '',
  ), $atts ) );

  $client = ( ! empty( $atts['project_client'] ) ) ? $atts['project_client'] : '';
  $date   = ( ! empty( $atts['project_date'] ) ) ? $atts['project_date'] : '';
  $link   = ( ! empty( $atts['project_link'] ) ) ? $atts['project_link'] : '';

  ob_start();
?>
<div class="col-sm-10 col-sm-offset-1">
  <div class="row work-full-detail mb40">
    <div class="col-sm-4">
      <p>
        <b><?php _e( 'Client:', 'brainwave' ); ?></b>
        <?php echo $project_client; ?>
      </p>
    </div>
    <div class="col-sm-4">
      <p>
        <b><?php _e( 'Date:', 'brainwave' ); ?></b>
        <?php echo $project_date; ?>
      </p>
    </div>
    <div class="col-sm-4">
      <p>
        <b><?php _e( 'Online:', 'brainwave' ); ?></b>
        <a href="<?php echo esc_url( $project_link ); ?>" target="_blank"><?php echo $project_link; ?></a>
      </p>
    </div>
  </div>
</div>

<?php
  return ob_get_clean();
}
add_shortcode( 'project_details', 'bw_project_details_shortcode' );

function bw_vc_project_details_shortcode() {
  vc_map( array(
    "name"            => __( "Project Details", "brainwave" ),
    "base"            => "project_details",
    "category"        => __( "Content", "brainwave" ),
    "content_element" => true,
    "params"          => array(
      array(
        "type"        => "textfield",
        "heading"     => __( "Client", "brainwave" ),
        "param_name"  => "project_client",
        "value"       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Date", "brainwave" ),
        "param_name"  => "project_date",
        "value"       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Link", "brainwave" ),
        "param_name"  => "project_link",
        "value"       => '',
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_project_details_shortcode' );

?>
