<?php

function bw_promo_photo_shortcode( $atts, $content = null ) {
  extract( shortcode_atts( array(
    'img'         => '',
    'after_page'  => '',
  ), $atts ) );
  $images       = ( ! empty( $atts['img'] ) ) ? $atts['img'] . ',' : '';

  if ( empty( $images ) ) {
    return;
  }

  $temp         = 0;
  $el_count     = substr_count ( $images , ',' );
  $start_point  = ( floor( $el_count / 2 ) + ( $el_count % 2 ) ) - $el_count;
  $sizes = array(
    '200x200',
    '171x171',
    '200x150'
  );
  ob_start();
?>

  <div class="text-center">
    <div class="promo-photo-block">
      <div class="promo-photo-block-wrapper">
        <?php
          for ( $i=0; $i < strlen( $images ); $i++ ) {
            if ( $images[ $i ] === ',' ) {
              $curr_img = substr( $images, $temp, $i - $temp );
              $temp = $i+1;
              $curr_img = wp_get_attachment_image_src( $curr_img, $sizes[ abs( $start_point ) ] );
              echo '<div class="block' . esc_attr( $start_point ) . '">';
              echo '<img src="' . esc_url( $curr_img[0] ) . '" alt="">';
              echo '</div> ';
              $start_point++;
            }
          }
        ?>
      </div><!-- .promo-photo-block-wrapper -->
    </div><!-- .promo-photo-block -->
  </div>

<?php
  return ob_get_clean();
}
add_shortcode( 'promo-photo', 'bw_promo_photo_shortcode' );

function bw_vc_promo_photo_shortcode() {
   vc_map( array(
      "name"      => __( "Promo photos", "brainwave" ),
      "base"      => "promo-photo",
      "category"  => __( "Content", "brainwave"),
      "params"    => array(
        array(
          "type"        => "attach_images",
          "heading"     => __( "Images", "brainwave" ),
          "param_name"  => "img",
          "value"       => '',
        ),
        array(
          "type"        => "checkbox",
          "heading"     => __( "Show this block after page", "brainwave" ),
          "param_name"  => "after_page",
          "value"       => '',
        ),
        array(
          'type'        => 'css_editor',
          'heading'     => __( 'CSS box', 'brainwave' ),
          'param_name'  => 'css',
          'group'       => __( 'Design Options', 'brainwave' )
        ),
      )
    )
  );
}
add_action( 'vc_before_init', 'bw_vc_promo_photo_shortcode' );

?>
