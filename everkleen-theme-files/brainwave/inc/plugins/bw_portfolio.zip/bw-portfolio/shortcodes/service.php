<?php

function bw_services_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'type'              => '',
    'icon_lib'          => '',
    'icon_fontawesome'  => '',
    'icon_elegant'      => '',
    'icon_etline'       => '',
    'icon_simpleline'   => '',
    'text'              => '',
    'is_link'           => '',
    'link'              => '',
    'desc'              => '',
    'animation'         => '',
    'delay'             => '',
    'css'               => '',
  ), $atts ) );

  $type      = ( ! empty( $atts['type'] ) ) ? $atts['type'] : 'bordered';
  $delay      = ( ! empty( $atts['delay'] ) ) ? $atts['delay'] : '0';
  $animation  = ( ! empty( $atts['animation'] ) ) ? $atts['animation'] . ' wow' : '';
  $text       = ( ! empty( $atts['text'] ) ) ? $atts['text'] : '';
  $is_link    = ( ! empty( $atts['is_link'] ) ) ? true : false;
  $link       = ( ! empty( $atts['link'] ) ) ? $atts['link'] : '#';
  $desc       = ( ! empty( $atts['desc'] ) ) ? $atts['desc'] : '';


  $container = ($is_link) ? 'a href="' . esc_url( $link ) . '"' : 'div';

  switch ( $icon_lib ) {
    case 'etline':
      $icon   = ( ! empty( $atts['icon_etline'] ) ) ? $atts['icon_etline'] : '';
      break;
    case 'elegant':
      $icon   = ( ! empty( $atts['icon_elegant'] ) ) ? $atts['icon_elegant'] : '';
      break;
    case 'simpleline':
      $icon   = ( ! empty( $atts['icon_simpleline'] ) ) ? $atts['icon_simpleline'] : '';
      break;
    default:
      $icon   = ( ! empty( $atts['icon_fontawesome'] ) ) ? $atts['icon_fontawesome'] : '';
      break;
  }

  $css_class  = '';
  ob_start();
  if ( isset( $atts['css'] ) ) :
    $css        = $atts['css'];
    $css_class  = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );

?>
    <style type="text/css">
      <?php echo $css; ?>
    </style>
<?php
  endif;
  if ( $type == 'bordered' ) :
?>
    <<?php echo $container; ?> <?php echo 'class="service ' . esc_attr( $css_class ) . ' ' . esc_attr( $animation ) . '" data-wow-delay="' . esc_attr( $delay ) . 's"'; ?> >
      <div class="icon-wrapper">
        <div class="icon-box">
          <span class="<?php echo esc_attr( $icon ); ?>"></span>
        </div>
      </div>
      <div class="title"><?php echo $text; ?></div>
    </<?php echo $container; ?>><!-- .service -->
<?php else : ?>
  <<?php echo $container; ?> <?php echo 'class="alt-service-item align-center ' . esc_attr( $css_class ) . ' ' . esc_attr( $animation ) . '" data-wow-delay="' . esc_attr( $delay ) . 's"'; ?>>
    <div class="alt-service-icon"> <span class="<?php echo esc_attr( $icon ); ?>"></span> </div>
    <h3 class="alt-service-title font-alt"><?php echo $text; ?></h3>
    <div class="alt-service-descr align-left"><?php echo $desc; ?></div>
  </<?php echo $container; ?>>
<?php
  endif;
  return ob_get_clean();
}
add_shortcode( 'services', 'bw_services_shortcode' );

function bw_services_container_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'after_page' => '',
  ), $atts ) );
  ob_start();
  echo apply_filters( 'the_content', $content );
  return ob_get_clean();
}
add_shortcode( 'services_container', 'bw_services_container_shortcode' );

function bw_vc_services_shortcode() {
  $new_animations = bw_get_animations();

  vc_map( array(
    "name"            => __( "Services", "brainwave" ),
    "base"            => "services_container",
    "category"        => __( "Content", "brainwave" ),
    'content_element' => true,
    'is_container'    => true,
    'custom_markup'   => '
      <div class="clearfix wpb_holder vc_container_for_children">
      </div>
      <div class="tab_controls">
        <a class="add_service">' . __( 'Add Service', 'brainwave' ) . '</a>
      </div>
    ',
    'default_content' => '
      [services]
      [services]
      [services]
      [services]
      [services]
    ',
    "params"          => array(
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
    ),
    'js_view'         => 'ServiceView',
  ) );
  vc_map( array(
    "name"            => __( "Service Block", "brainwave" ),
    "base"            => "services",
    "category"        => __( "Content", "brainwave" ),
    'content_element' => true,
    "params"          => array(
      array(
        "type"        => "dropdown",
        "heading"     => __( "Block Type", "brainwave" ),
        "param_name"  => "type",
        "value"       => array(
          'Bordered (default)' => 'bordered',
          'Alt' => 'alt',
        ),
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Icon Library", "brainwave" ),
        "param_name"  => "icon_lib",
        "value"       => array(
          'Font Awesome' => 'fontawesome',
          'Et Line' => 'etline',
          'Simple Line' => 'simpleline',
          'Elegant' => 'elegant',
        ),
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_elegant',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'elegant',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'elegant',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_etline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'etline',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'etline',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_simpleline',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'simpleline',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'simpleline',
        ),
        'value'       => '',
      ),
      array(
        'type'        => 'iconpicker',
        'heading'     => __( 'Icon', 'brainwave' ),
        'param_name'  => 'icon_fontawesome',
        'settings'    => array(
          'emptyIcon'     => true, // default true, display an "EMPTY" icon? - if false it will display first icon
          'iconsPerPage'  => 200, // default 100, how many icons per/page to display
          'type'      => 'fontawesome',
        ),
        'dependency' => array(
            'element' => 'icon_lib',
            'value' => 'fontawesome',
        ),
        'value'       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Delay", "brainwave" ),
        "param_name"  => "delay",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Animation", "brainwave" ),
        "param_name"  => "animation",
        "value"       => $new_animations,
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Text", "brainwave" ),
        "param_name"  => "text",
        "value"       => "",
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Add link", "brainwave" ),
        "param_name"  => "is_link",
        "value"       => "",
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Link", "brainwave" ),
        "param_name"  => "link",
        'dependency' => array(
            'element' => 'is_link',
            'value' => 'true',
        ),
        "value"       => "#",
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Description", "brainwave" ),
        "param_name"  => "desc",
        'dependency' => array(
            'element' => 'type',
            'value' => 'alt',
        ),
        "value"       => "",
      ),
      array(
        'type'        => 'css_editor',
        'heading'     => __( 'CSS box', 'brainwave' ),
        'param_name'  => 'css',
        'group'       => __( 'Design Options', 'brainwave' )
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_services_shortcode' );

?>
