<?php

function bw_skills_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'theme'       => 'light',
    'skill'       => '',
    'percent'     => '',
    'after_page'  => '',
    'css'         => '',
  ), $atts ) );

  $theme      = ( ! empty( $atts['theme'] ) ) ? $atts['theme'] : 'light';
  $skill      = ( ! empty( $atts['skill'] ) ) ? $atts['skill'] : '';
  $percent    = ( ! empty( $atts['percent'] ) ) ? (int) $atts['percent'] : 0;

  $css_class  = '';
  ob_start();
  if ( isset( $atts['css'] ) ) :
    $css        = $atts['css'];
    $css_class  = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );

?>
    <style type="text/css">
      <?php echo $css; ?>
    </style>
<?php
  endif;
?>
  <div class="skill <?php echo esc_attr( $theme ); echo ( ! empty( $css ) ) ? esc_attr( $css_class ) : ''; ?>">
    <div class="title"><?php echo $skill; ?></div>
    <div class="skill-progress-bar" data-progress-animation="<?php echo esc_attr( $percent ); ?>" data-progress-text="0"></div>
  </div>
  <!-- .skill -->
<?php
  return ob_get_clean();
}
add_shortcode( 'skills', 'bw_skills_shortcode' );

function bw_vc_skills_shortcode() {
  vc_map( array(
    "name"            => __( "Skills", "brainwave" ),
    "base"            => "skills",
    "category"        => __( "Content", "brainwave" ),
    'content_element' => true,
    "params"          => array(
      array(
        "type"        => "dropdown",
        "heading"     => __( "Theme", "brainwave" ),
        "param_name"  => "theme",
        "value"       => array(
          'Light' => 'light',
          'Dark' => 'dark',
        ),
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Skill", "brainwave" ),
        "param_name"  => "skill",
        "value"       => "",
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Percent", "brainwave" ),
        "param_name"  => "percent",
        "value"       => "",
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
      array(
        'type'        => 'css_editor',
        'heading'     => __( 'CSS box', 'brainwave' ),
        'param_name'  => 'css',
        'group'       => __( 'Design Options', 'brainwave' )
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_skills_shortcode' );

?>
