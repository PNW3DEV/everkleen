<?php

function bw_slider_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'bg_img'      => '',
    'arrows'      => '',
    'dots'        => '',
    'after_page'  => '',
    'css'         => '',
  ), $atts ) );
  $bg_img     = ( ! empty($atts['bg_img'] ) ) ? $atts['bg_img'] : '';
  $arrows     = ( ! empty($atts['arrows'] ) ) ? $atts['arrows'] : '';
  $dots       = ( ! empty($atts['dots'] ) ) ? $atts['dots'] : '';
  $css_class  = '';
  ob_start();
  if ( isset( $atts['css'] ) ) :
    $css        = $atts['css'];
    $css_class  = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
?>
    <style type="text/css">
      <?php echo $css; ?>
    </style>
<?php
  endif;

  $classes = 'owl-carousel default-carousel';
  if ( has_shortcode( $content, 'team_slide' ) ) :
    $classes .= ' team-carousel';
  endif;
  if ( $arrows ) :
    $classes .= ' no-arrow';
  endif;
  if ( $dots ) :
    $classes .= ' no-dots';
  endif;
  if ( has_shortcode( $content, 'team_slide' ) ) :
    $classes .= ' team-carousel';
  endif;
  if ( has_shortcode( $content, 'testimonial_slide' ) ) :
    $classes .= ' testimonials animation-fade';
  endif;
  if ( has_shortcode( $content, 'client_slide' ) ) :
    $classes .= ' mb60 client-carousel';
  endif;

  if ( ! empty( $bg_img ) ) :
  ?>
    <div class="bg-section" data-background="<?php echo esc_attr( wp_get_attachment_url( $bg_img ) ); ?>" data-overlay-color="#191919" data-overlay-opacity="0.9">
      <div class="<?php echo esc_attr( $classes ); ?>"><?php remove_filter( 'the_content', 'wpautop' ); echo apply_filters( 'the_content', $content ); add_filter( 'the_content', 'wpautop' ); ?></div>
    </div>
  <?php else : ?>
    <div class="<?php echo esc_attr( $classes ); ?>"><?php remove_filter( 'the_content', 'wpautop' ); echo apply_filters( 'the_content', $content ); add_filter( 'the_content', 'wpautop' ); ?></div>
  <?php
  endif;
  return ob_get_clean();
}
add_shortcode( 'slider', 'bw_slider_shortcode' );

function bw_vc_slider_shortcode() {
  vc_map( array(
    "name"                      => __( "Slider", "brainwave" ),
    "base"                      => "slider",
    "category"                  => __( "Content", "brainwave" ),
    "content_element"           => true,
    'allowed_container_element' => 'vc_row',
    "is_container"              => true,
    "params"                    => array(
      array(
        'type'        => 'attach_image',
        'heading'     => __( 'Background Image', 'brainwave' ),
        'param_name'  => 'bg_img',
        'value'       => '',
      ),
      array(
        'type'        => 'checkbox',
        'heading'     => __( 'No Arrows', 'brainwave' ),
        'param_name'  => 'arrows',
        'value'       => true,
      ),
      array(
        'type'        => 'checkbox',
        'heading'     => __( 'No Dots', 'brainwave' ),
        'param_name'  => 'dots',
        'value'       => true,
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
      array(
        'type'        => 'css_editor',
        'heading'     => __( 'CSS box', 'brainwave' ),
        'param_name'  => 'css',
        'group'       => __( 'Design Options', 'brainwave' )
      ),
    ),
    'custom_markup'   => '
      <div class="vc_container_for_children">
      </div>
      <div class="vc_empty-container">
      </div>
    ',
    'js_view'         => 'SliderView',
  ) );
}
add_action( 'vc_before_init', 'bw_vc_slider_shortcode' );

?>
