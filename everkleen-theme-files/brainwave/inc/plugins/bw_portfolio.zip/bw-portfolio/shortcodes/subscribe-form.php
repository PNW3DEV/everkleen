<?php

function bw_subscribe_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'variant'     => '',
    'header'      => '',
    'text'        => '',
    'placeholder' => '',
    'btn_text'    => '',
    'api_key'     => '',
    'list_id'     => '',
    'after_page'  => '',
  ), $atts ) );

  $variant      = ( ! empty( $atts['variant'] ) ) ? $atts['variant'] : 'mailchimp';
  $header       = ( ! empty( $atts['header'] ) ) ? $atts['header'] : '';
  $text         = ( ! empty( $atts['text'] ) ) ? $atts['text'] : '';
  $placeholder  = ( ! empty( $atts['placeholder'] ) ) ? $atts['placeholder'] : '';
  $btn_text     = ( ! empty( $atts['btn_text'] ) ) ? $atts['btn_text'] : 'Subscribe';
  $m_key        = ( ! empty( $atts['api_key'] ) ) ? $atts['api_key'] : '';
  $m_list_id    = ( ! empty( $atts['list_id'] ) ) ? $atts['list_id'] : '';

  ob_start();

  if ( $variant == 'mailchimp' ) :
?>

  <div class="newsletter-block text-center">
    <div class="h5 text-uppercase opacity-60"><?php echo $header; ?></div>
    <div class="h2 text-uppercase mt14 mb30"><?php echo $text; ?></div>
    <form id="chimp">
      <input type="text" value="" name="email" id="email" class="email form-control subscriber" placeholder="<?php echo esc_attr( $placeholder ); ?>">
      <input type="hidden" value="<?php echo esc_attr( $m_key ); ?>" id="mcapi">
      <input type="hidden" value="<?php echo esc_attr( $m_list_id ); ?>" id="mclistid">
      <input type="submit" value="<?php echo esc_attr( $btn_text ); ?>" id="btn-chimp-subscribe" class="btn btn-primary">
      <div class="msg">&nbsp; </div>
    </form>
  </div>

<?php else : ?>

  <div class="newsletter-block text-center">
    <div class="h5 text-uppercase opacity-60"><?php echo $header; ?></div>
    <div class="h2 text-uppercase mt14 mb30"><?php echo $text; ?></div>
    <form id="subscribe">
      <input type="text" name="email" class="form-control subscriber" placeholder="<?php echo esc_attr( $placeholder ); ?>">
      <input id='btn-subscribe' type="submit" value="<?php echo esc_attr( $btn_text ); ?>" class="btn btn-primary">
      <div class="msg">&nbsp; </div>
    </form>
  </div>

<?php
  endif;

  return ob_get_clean();
}
add_shortcode( 'subscribe', 'bw_subscribe_shortcode' );

function bw_vc_subscribe_shortcode() {

  vc_map( array(
    "name"            => __( "Subscribe Form", "brainwave" ),
    "base"            => "subscribe",
    "category"        => __( "Content", "brainwave" ),
    "content_element" => true,
    "params"          => array(
      array(
        "type"        => "dropdown",
        "heading"     => __( "Subscribe Variant", "brainwave" ),
        "param_name"  => "variant",
        "value"       => array(
          'Mailchimp'   => 'mailchimp',
          'To Database' => 'todb',
        ),
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Mailchimp API Key", "brainwave" ),
        "param_name"  => "api_key",
        'dependency'  => array(
          'element' => 'variant',
          'value'   => 'mailchimp',
        ),
        "value"       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Mailchimp List ID", "brainwave" ),
        "param_name"  => "list_id",
        'dependency'  => array(
          'element' => 'variant',
          'value'   => 'mailchimp',
        ),
        "value"       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Header", "brainwave" ),
        "param_name"  => "header",
        "value"       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Text", "brainwave" ),
        "param_name"  => "text",
        "value"       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Placeholder", "brainwave" ),
        "param_name"  => "placeholder",
        "value"       => '',
      ),
      array(
        "type"        => "textfield",
        "heading"     => __( "Text on button", "brainwave" ),
        "param_name"  => "btn_text",
        "value"       => '',
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_subscribe_shortcode' );

?>
