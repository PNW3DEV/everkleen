<?php

function bw_team_slide_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'team_img'  => '',
    'team_name' => '',
    'team_role' => '',
  ), $atts ) );
  $team_img    = ( ! empty( $atts['team_img'] ) ) ? $atts['team_img'] : '';
  $team_name   = ( ! empty( $atts['team_name'] ) ) ? $atts['team_name'] : '';
  $team_role   = ( ! empty( $atts['team_role'] ) ) ? $atts['team_role'] : '';

  ob_start();
?>
  <div class="team-item">
    <img src="<?php echo esc_url( wp_get_attachment_url( $team_img ) ); ?>" alt="">
    <div class="description">
      <div class="team-item-name"><?php echo $team_name; ?></div>
      <div class="team-item-role"><?php echo $team_role;?></div>
    </div>
  </div>
<?php
  return ob_get_clean();
}
add_shortcode( 'team_slide', 'bw_team_slide_shortcode' );

function bw_vc_team_slide_shortcode() {
  vc_map( array(
    "name"            => __( "Team Slide", "brainwave" ),
    "base"            => "team_slide",
    "category"        => __( "Content", "brainwave" ),
    "content_element" => true,
    "params"          => array(
      array(
        'type'        => 'attach_image',
        'heading'     => __( 'Image', 'brainwave' ),
        'param_name'  => 'team_img',
        'value'       => '',
      ),
      array(
        'type'        => 'textfield',
        'heading'     => __( 'Name', 'brainwave' ),
        'param_name'  => 'team_name',
        'value'       => '',
      ),
      array(
        'type'        => 'textfield',
        'heading'     => __( 'Role', 'brainwave' ),
        'param_name'  => 'team_role',
        'value'       => '',
      ),
    ),
  ) );
}
add_action( 'vc_before_init', 'bw_vc_team_slide_shortcode' );

?>
