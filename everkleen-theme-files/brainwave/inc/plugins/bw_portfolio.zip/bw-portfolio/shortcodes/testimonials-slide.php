<?php

function bw_testimonial_slide_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'testimonial_header'  => '',
    'testimonial_text'    => '',
    'testimonial_author'  => '',
  ), $atts ) );
  $testimonial_header = $atts['testimonial_header'];
  $testimonial_text   = $atts['testimonial_text'];
  $testimonial_author = $atts['testimonial_author'];
  ob_start();
?>

  <div class="carousel-item page-section">
    <div class="text-center">
      <span class="et-icon-chat white opacity-75"></span>
      <div class="title white text-uppercase opacity-75"><?php echo $testimonial_header; ?></div>
      <div class="testimonial white opacity-75"><?php echo $testimonial_text; ?></div>
      <div class="client white opacity-30"><?php echo $testimonial_author; ?></div>
    </div>
  </div><!-- .carousel-item -->

<?php
  return ob_get_clean();
}
add_shortcode( 'testimonial_slide', 'bw_testimonial_slide_shortcode' );

function bw_vc_testimonial_slide_shortcode() {
  vc_map( array(
    "name"            => __( "Testimonial Slide", "brainwave" ),
    "base"            => "testimonial_slide",
    "category"        => __( "Content", "brainwave" ),
    "content_element" => true,
    "params"          => array(
      array(
        'type'        => 'textfield',
        'heading'     => __( 'Header', 'brainwave' ),
        'param_name'  => 'testimonial_header',
        'value'       => '',
      ),
      array(
        'type'        => 'textfield',
        'heading'     => __( 'Text', 'brainwave' ),
        'param_name'  => 'testimonial_text',
        'value'       => '',
      ),
      array(
        'type'        => 'textfield',
        'heading'     => __( 'Author', 'brainwave' ),
        'param_name'  => 'testimonial_author',
        'value'       => '',
      ),
      array(
        'type'        => 'css_editor',
        'heading'     => __( 'CSS box', 'brainwave' ),
        'param_name'  => 'css',
        'group'       => __( 'Design Options', 'brainwave' )
      ),
    ),
  ) );
}
add_action( 'vc_before_init', 'bw_vc_testimonial_slide_shortcode' );

?>
