<?php

function bw_text_rotator_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'animation'   => '',
    'text'        => '',
    'after_page'  => '',
  ), $atts ) );
  $text       = ( ! empty( $atts['text'] ) ) ? $atts['text'] : '';
  $animation  = ( ! empty( $atts['animation'] ) ) ? $atts['animation'] : '';
  ob_start();
  echo '<span class="js-rotating" data-animation="' . esc_attr( $animation ) . '">' . $text . '</span>';
  return ob_get_clean();
}
add_shortcode( 'text-rotator', 'text_rotator_shortcode' );

function bw_vc_text_rotator_shortcode() {

  $animations = '{

    "attention_seekers": {
      "bounce": true,
      "flash": true,
      "pulse": true,
      "rubberBand": true,
      "shake": true,
      "swing": true,
      "tada": true,
      "wobble": true
    },

    "bouncing_entrances": {
      "bounceIn": true,
      "bounceInDown": true,
      "bounceInLeft": true,
      "bounceInRight": true,
      "bounceInUp": true
    },

    "fading_entrances": {
      "fadeIn": true,
      "fadeInDown": true,
      "fadeInDownBig": true,
      "fadeInLeft": true,
      "fadeInLeftBig": true,
      "fadeInRight": true,
      "fadeInRightBig": true,
      "fadeInUp": true,
      "fadeInUpBig": true
    },

    "flipping_entrances": {
      "flip": true,
      "flipInX": true,
      "flipInY": true
    },

    "rotating_entrances": {
      "rotateIn": true,
      "rotateInDownLeft": true,
      "rotateInDownRight": true,
      "rotateInUpLeft": true,
      "rotateInUpRight": true
    },

    "zooming_entrances": {
      "zoomIn": true,
      "zoomInDown": true,
      "zoomInLeft": true,
      "zoomInRight": true,
      "zoomInUp": true
    },

    "others": {
      "lightSpeedIn": true,
      "rollIn": true
    }

  }
  ';
  $animations =  get_object_vars( json_decode( $animations ) );
  foreach ( $animations as $animation ) {
    $animation = get_object_vars( $animation );
    foreach ($animation as $key => $value) {
      $new_animations[ $key ] = $key;
    }
  }

  vc_map( array(
    "name"      => __( "Text Rotator", "brainwave" ),
    "base"      => "text-rotator",
    "category"  => __( "Content", "brainwave"),
    "params"    => array(
      array(
        "type"        => "textfield",
        "heading"     => __( "Text to Animate", "brainwave" ),
        "description" => __( "Phrases separated by comma", "brainwave" ),
        "param_name"  => "text",
        "value"       => '',
      ),
      array(
        "type"        => "dropdown",
        "heading"     => __( "Animation", "brainwave" ),
        "param_name"  => "animation",
        "value"       => $new_animations,
      ),
      array(
        "type"        => "checkbox",
        "heading"     => __( "Show this block after page", "brainwave" ),
        "param_name"  => "after_page",
        "value"       => '',
      ),
    )
  ) );
}
add_action( 'vc_before_init', 'bw_vc_text_rotator_shortcode' );

?>
