<?php

function bw_video_slide_shortcode( $atts, $content = null ) { // New function parameter $content is added!
  extract( shortcode_atts( array(
    'video_img'       => '',
    'video_url'       => '',
    'video_title'     => '',
    'video_subtitle'  => '',
  ), $atts ) );

  $video_img      = ( ! empty( $atts['video_img'] ) ) ? $atts['video_img'] : '';
  $video_url      = ( ! empty( $atts['video_url'] ) ) ? $atts['video_url'] : '';
  $video_title    = ( ! empty( $atts['video_title'] ) ) ? $atts['video_title'] : '';
  $video_subtitle = ( ! empty( $atts['video_subtitle'] ) ) ? $atts['video_subtitle'] : '';

  ob_start();
?>

  <div class="carousel-item">
    <div class="page-section bg-section" data-background="<?php echo esc_attr( wp_get_attachment_url( $video_img ) ); ?>" data-overlay-color="#191919" data-overlay-opacity="0.5">
      <div class="text-center">
        <a href="<?php echo esc_url( $video_url ); ?>" class="popup-youtube big-icon white"><div class="circle pulse"></div><i class="fa fa-play"></i></a>
        <div>
          <h2 class="text-uppercase title-3 white mt29"><?php echo $video_title; ?></h2>
        </div>
        <span class="sub-header white opacity-50 text-uppercase ls-02"><?php echo $video_subtitle; ?></span>
      </div>
    </div>
  </div><!-- .carousel-item -->

<?php
  return ob_get_clean();
}
add_shortcode( 'video_slide', 'bw_video_slide_shortcode' );

function bw_vc_video_slide_shortcode() {
  vc_map( array(
    "name"            => __( "Video Slide", "brainwave" ),
    "base"            => "video_slide",
    "category"        => __( "Content", "brainwave" ),
    "content_element" => true,
    "params"          => array(
      array(
        'type'        => 'attach_image',
        'heading'     => __( 'Background', 'brainwave' ),
        'param_name'  => 'video_img',
        'value'       => '',
      ),
      array(
        'type'        => 'textfield',
        'heading'     => __( 'Link', 'brainwave' ),
        'param_name'  => 'video_url',
        'value'       => '',
      ),
      array(
        'type'        => 'textfield',
        'heading'     => __( 'Title', 'brainwave' ),
        'param_name'  => 'video_title',
        'value'       => '',
      ),
      array(
        'type'        => 'textfield',
        'heading'     => __( 'Short Description', 'brainwave' ),
        'param_name'  => 'video_subtitle',
        'value'       => '',
      ),
    ),
  ) );
}
add_action( 'vc_before_init', 'bw_vc_video_slide_shortcode' );

?>
